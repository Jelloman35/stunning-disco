hook.Add( "RenderScreenspaceEffects", "Tricky_ScreenEffects", function()
local ply = LocalPlayer()
if ply:GetNWBool('TikyStatic',false) == true then
DrawMaterialOverlay( "overlays/slender/ticky", 0 )
end

end )
hook.Add( "RenderScreenspaceEffects", "Luigi_ScreenEffects", function()
local ply = LocalPlayer()
if ply:GetNWBool('LuigiJump',false) == true then
DrawMaterialOverlay( "overlays/slender/luigideath", 0 )
end

end )
hook.Add( "RenderScreenspaceEffects", "Green_ScreenEffects", function()
local ply = LocalPlayer()
if ply:GetNWBool('GreenJumpscare',false) == true then
DrawMaterialOverlay( "overlays/slender/weegi", 0 )
end

end )
hook.Add( "RenderScreenspaceEffects", "CWoody_ScreenEffects", function()
local ply = LocalPlayer()
if ply:GetNWBool('CwoodyJumpscare',false) == true then
DrawMaterialOverlay( "overlays/slender/omg_new_c_woody_deathscare", 0 )
end

end )
hook.Add( "RenderScreenspaceEffects", "CJessie_ScreenEffects", function()
local ply = LocalPlayer()
if ply:GetNWBool('CJessieJumpscare',false) == true then
DrawMaterialOverlay( "overlays/slender/omg_c_jessie_deathscare", 0 )
end

end )
hook.Add( "RenderScreenspaceEffects", "CWoodyT_ScreenEffects", function()
local ply = LocalPlayer()
if ply:GetNWBool('CWoodyTeleport',false) == true then
DrawMaterialOverlay( "overlays/slender/omg_new_c_woody_teleport", 0 )
end

end )
hook.Add( "RenderScreenspaceEffects", "PurpleGuy_ScreenEffects", function()
local ply = LocalPlayer()
if ply:GetNWBool('PurpleGuyJumpscare',false) == true then
DrawMaterialOverlay( "overlays/slender/fnaf2/purpleguy_death", 0 )
end

end )