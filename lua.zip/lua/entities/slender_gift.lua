
AddCSLuaFile();

DEFINE_BASECLASS("base_anim");

ENT.PrintName		= "Sniper's Gift";
ENT.Author			= "Jonascone";
ENT.Information		= "Collectable Slender pages!\nSlender Man+Pages addon required!";
ENT.Category		= "Slender Fortress";

ENT.Editable			= false;
ENT.Spawnable			= true;
ENT.AdminOnly			= false;
ENT.RenderGroup 		= RENDERGROUP_TRANSLUCENT;

local activeGift = {};

function ENT:SpawnFunction(ply, tr, ClassName)
    // If we're not looking at something, there're already 10 pages, or, we're looking at the ceiling or floor, don't spawn!
	if (table.Count(activeGift) >= 10) then return NULL; end
    
	local SpawnPos = tr.HitPos + tr.HitNormal - Vector(0, 0, 2);
	local ent = ents.Create(ClassName);
	local i = 0;
    while (i < 10) do
        if (!activeGift[i]) then
            activeGift[i] = ent;
            ent:SetSkin(0);
            break;
        end
        i = i + 1;
    end
    ent:SetPos(SpawnPos);
    ent:SetAngles(Angle(0, 0, 0));
	ent:Spawn();
    ent:GetPhysicsObject():EnableMotion(false);
	ent:Activate();
	return ent;	
end

function ENT:Initialize()
    if (CLIENT) then return; end
    self:SetModel(Model("models/items/tf_gift.mdl"));
    self:PhysicsInit(SOLID_VPHYSICS);
    self:SetMoveType(MOVETYPE_VPHYSICS);
    self:SetSolid(SOLID_VPHYSICS); 
    local phys = self:GetPhysicsObject();
    if (phys:IsValid()) then
        phys:Wake();
    end	
end

function ENT:Draw()
    self:DrawModel();
end

function ENT:PrintGift(ply)    
    ply:PrintMessage(HUD_PRINTCENTER, "Recovered " .. ply.numGift .. " of 10 Sniper's Gifts");
end

function ENT:RemoveGift()
    if (CLIENT) then return; end
    for k, v in pairs(activeGift) do
        if (v == self) then
            activeGift[k] = nil;
         end
    end
    self:Remove();
end

function ENT:OnRemove()
    if (CLIENT) then return; end
    self:RemoveGift();
end
function ENT:Use(ply, caller)
    if (CLIENT or ply:GetEyeTraceNoCursor().Entity != self) then return; end // Only remove the page if the player is aiming at it.
    ply.numGift = ply.numGift and ply.numGift < 10 and ply.numGift + 1 or 1;
    self:PrintGift(ply);
    ply:EmitSound(Sound("ui/item_cardboard_pickup.wav"), 100.0, math.random(100, 100));
    self:RemoveGift();
end

hook.Add("PreDrawHalos", "SlenderGiftHalo", function()
    halo.Add(ents.FindByClass("slender_Gift"), Color(128, 128, 128), 1, 1, 1);
end);