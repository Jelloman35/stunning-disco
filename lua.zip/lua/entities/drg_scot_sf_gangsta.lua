if not DrGBase then return end -- return if DrGBase isn't installed
ENT.Base = "drgbase_nextbot" -- DO NOT TOUCH (obviously)

-- Misc --
ENT.PrintName = "Gangsta Doctor"
ENT.Category = "Slender Fortress"
ENT.Models = {"models/mentrillum/isjoke/gangsta049.mdl"}
ENT.BloodColor = BLOOD_COLOR_RED
ENT.CollisionBounds = Vector(14, 14, 83)
ENT.RagdollOnDeath = true
ENT.SpotDuration = 5

-- Stats --
ENT.SpawnHealth = 90000
ENT.ShoveResistance = true
ENT.DamageMultipliers = {}

-- AI --
ENT.MeleeAttackRange = 50
ENT.ReachEnemyRange = 50
ENT.AvoidEnemyRange = 0

-- Relationships --
ENT.Factions = {"FACTION_SLENDER"}
ENT.Frightening = true

-- Movements/animations --
ENT.UseWalkframes = false
ENT.WalkAnimation = "gangsta_walk"
ENT.RunAnimation = "gangstas_paradise"
ENT.IdleAnimation = "gangsta_idle"
ENT.JumpAnimation = "gangstas_paradise"
ENT.RunSpeed = 310
ENT.WalkSpeed = 35

-- Climbing --
ENT.ClimbLedges = false
ENT.ClimbProps = false
ENT.ClimbLadders = false

-- Detection --
ENT.EyeBone = "head"
ENT.EyeOffset = Vector(10, 0, 1)
ENT.EyeAngle = Angle(0, 0, 0)

-- Possession --
ENT.PossessionEnabled = true
ENT.PossessionMovement = POSSESSION_MOVE_1DIR
ENT.PossessionViews = {
	{
		offset = Vector(0, 15, 15),
		distance = 70
	},
	{
		offset = Vector(7.5, 0, 0),
		distance = 0,
		eyepos = true
	}
}
ENT.PossessionBinds = {
	[IN_ATTACK] = {{
		coroutine = true,
		onkeydown = function(self)
			if self:GetCooldown("NemesisRangeAttack") == 0 then
			self:SetCooldown("NemesisRangeAttack",math.random(1,1))
			self:PlaySequence("AttackStand_Melee_allclass")
			self:Timer(0.3, function()
			self:AttackFunction(65,self.DamageType)
			end)
			end
		end
	}},
	[IN_JUMP] = {{coroutine = true,onkeydown = function(self)self:Jump()end}}
}

if SERVER then
function ENT:AttackFunction(dmg,dmgtype,sndhit)
	self:Attack({
		damage = dmg,
		viewpunch = Angle(40, 0, 0),
		type = dmgtype,
		range=self.MeleeAttackRange-math.random(10),
		angle=135,
	}, function(self, hit)
		if self:GetSequenceName(self:GetSequence())=="att4" then return end
		if #hit == 0 then self:EmitSound("")return end 
		self:EmitSound("")
	end)
end

function ENT:CustomInitialize()
	self:EmitSound("slender/gangsta049/gangsta_breath.wav")
	self:SetDefaultRelationship(D_HT, 1)
	self:SetAttack("att1_l", true)
	self:SetCooldown("Twitch",math.random(3,3))
end
function ENT:Step()
	self:EmitSound("slender/wehappyfew/bobby_step"..math.random(2)..".wav")
end

function ENT:OnLandOnGround()
	if self:IsDead() then return end
	self:CallInCoroutineOverride(function(self, delay)
		self:PlaySequence("jumpland_MELEE_ALLCLASS")
	end)
end

function ENT:OnSpawn()
end

function ENT:OnMeleeAttack(enemy)
	self:AttackFunction(420,self.DamageType)
end
-- Damage --
function ENT:OnTraceAttack(dmg,dir,tr)
end
function ENT:OnPhysDamage(ent, data)
	if string.find(data.HitEntity:GetClass(), "tf_") then return end
	return (data.TheirOldVelocity:Length()*data.HitObject:GetMass())/1000
end
function ENT:_HandleCollide(data)
	if string.find(data.HitEntity:GetClass(), "tf_") then return end
	local ent = data.HitEntity
	if not IsValid(ent) then return end
	local class = ent:GetClass()
	local phys = data.HitObject
	if class == "prop_combine_ball" then
	if self:IsFlagSet(FL_DISSOLVING) then return end
	if not self:OnCombineBall(ent) then
	if not self:IsDead() then
		local dmg = DamageInfo()
		local owner = ent:GetOwner()
		dmg:SetAttacker(IsValid(owner) and owner or ent)
		dmg:SetInflictor(ent)
		dmg:SetDamage(1000)
		dmg:SetDamageType(DMG_DISSOLVE)
		dmg:SetDamageForce(ent:GetVelocity())
		self:TakeDamageInfo(dmg)
	else self:DrG_Dissolve() end
	ent:EmitSound("NPC_CombineBall.KillImpact")
	end
	elseif not ent:IsPlayerHolding() then
	local damage = math.floor(self:OnPhysDamage(ent, data))
	if damage > math.max(0, self.MinPhysDamage) then
		local dmg = DamageInfo()
		if ent:IsVehicle() and IsValid(ent:GetDriver()) then
		dmg:SetAttacker(ent:GetDriver())
		elseif IsValid(ent:GetPhysicsAttacker()) then
		dmg:SetAttacker(ent:GetPhysicsAttacker())
		else dmg:SetAttacker(ent) end
		dmg:SetInflictor(ent)
		dmg:SetDamage(damage)
		if ent:IsVehicle() then
		dmg:SetDamageType(DMG_VEHICLE)
		else dmg:SetDamageType(DMG_CRUSH) end
		dmg:SetDamageForce(phys:GetVelocity())
		self:TakeDamageInfo(dmg)
		end
	end
end
function ENT:OnNewEnemy(enemy)
end
function ENT:OnOtherKilled(ent, dmg)
end
function ENT:OnOtherKilled(ent, dmg)
	local attacker = dmg:GetAttacker()
	if IsValid(attacker) and attacker == self then
		if ent:IsPlayer() then
		local p = math.random(1,21)
		if p==1 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." couldn't take the pestilence.")
		elseif p==2 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." 'Plague is no more, as per your request'")
		elseif p==3 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." was the one who contained the virus.")
		elseif p==4 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." didn't join the Gangsta's Paradise with the Gangsta Doctors.")
		elseif p==5 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." obtained the bubonic plague and didn't survive.")
		elseif p==6 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." didn't want SCP-049 to cure them, so Gangsta Doctor did them a favor.")
		elseif p==7 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." failed to do Gangsta Doctor's walk.")
		elseif p==8 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." snezzed.")
		elseif p==9 then
		PrintMessage(HUD_PRINTTALK, ent:Name().."'s disease of lawlessness was purged with fire, because it was the Gangsta Doctor.")
		elseif p==10 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." attempted to infect the Gangsta Doctor with the pestilence, little did they know the Gangsta Doctor is a carrier.")
		elseif p==11 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." didn't think that SCP-049 could breach containment. But wait, thats not SCP-049?")
		elseif p==12 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." thought the Gangsta Doctor was a knock off of Major Grom: Plague Doctor.")
		elseif p==13 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." tried to use SCP-714 against the Gangsta Doctor, but the ring was taken off.")
		elseif p==14 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." said that Coolio's songs aren't that good. Gangsta Doctor didn't like that form of disease.")
		elseif p==15 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." was too afraid of the Gangsta Doctor. Do not be afraid, he is the cure.")
		elseif p==16 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." was given the common cold, then cured by the Gangsta Doctor.")
		elseif p==17 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." wanted to get infected to see this death message. Thats a sickening way to end your life.")
		elseif p==18 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." lost their medical license to the Gangsta Doctor.")
		elseif p==19 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." was a scheduled patient for Gangsta Doctor. Luckily they were cured on time.")
		elseif p==20 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." coughed.")
		elseif p==21 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." was sent to the Gangsta's Paradise.")
		end
		end
		GangKill = "slender/gangsta049/gangsta_death.mp3"
			local locateplayers = player.GetAll()
			for i = 1, table.getn(locateplayers) do
			locateplayers[i]:ConCommand("play " .. GangKill .. "\n")
			end
	end
end

function ENT:OnFatalDamage()return false end
function ENT:OnDeath(dmg)
	self:StopSound("slender/duckmedic/chase_music.wav")
end
function ENT:OnRagdoll()
end
function ENT:OnLost()
end
function ENT:OnIdle()
	self:AddPatrolPos(self:RandomPos(1500))
end
function ENT:OnRemove()
	self:StopSound("slender/gangsta049/gangsta_breath.wav")
end

function ENT:CustomThink()
	self:RemoveAllDecals()
end
function ENT:OnUpdateAnimation()
	if self:IsDead() then return end
	if !self:IsOnGround() then return self.JumpAnimation, 1
	elseif self:IsRunning() then return self.RunAnimation, self.RunAnimRate
	elseif self:IsMoving() then return self.WalkAnimation, self.WalkAnimRate
	else return self.IdleAnimation, self.IdleAnimRate end
end

function ENT:CallInCoroutineOverride(callback)
	local oldThread = self.BehaveThread
	self.BehaveThread = coroutine.create(function()
		callback(self)
		self.BehaveThread = oldThread
	end)
end
end

-- DO NOT TOUCH --
AddCSLuaFile()
DrGBase.AddNextbot(ENT)