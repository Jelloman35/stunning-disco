AddCSLuaFile()
ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.Spawnable = false

function ENT:Draw()
self.Entity:DrawModel()
end

function ENT:Initialize()
if SERVER then
self.Entity:SetModel( "models/props_lakeside_event/bomb_temp.mdl" )
self.Entity:SetMoveType( MOVETYPE_VPHYSICS )
self.Entity:SetSolid( SOLID_VPHYSICS )
self.Entity:PhysicsInit( SOLID_VPHYSICS )
self.Entity:SetCollisionGroup( COLLISION_GROUP_INTERACTIVE )
self.Entity:DrawShadow( false )
end
self.ExplodeTimer = CurTime() + 2.3
end

function ENT:Think()
if SERVER then
if self.ExplodeTimer <= CurTime() then
self.Entity:Remove()
end
end
end

function ENT:PhysicsCollide( data )
if SERVER then
if string.find(data.HitEntity:GetClass(), "npc_") or string.find(data.HitEntity:GetClass(), "player") then
self.Entity:SetMoveType( MOVETYPE_NONE )
self.Entity:SetSolid( SOLID_NONE )
self.Entity:PhysicsInit( SOLID_NONE )
self.Entity:SetCollisionGroup( COLLISION_GROUP_NONE )
self.Entity:Remove()
end
end
end

function ENT:OnRemove()
if SERVER then
ParticleEffect("merasmus_bomb_explosion",self:LocalToWorld(Vector(0,0,0)),Angle(0,0,0),nil)
self:EmitSound("weapons/explode"..math.random(2)..".wav")
end
util.BlastDamage( self, self, self:GetPos(), 146, 100 )
end