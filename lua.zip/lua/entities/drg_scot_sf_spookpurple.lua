if not DrGBase then return end -- return if DrGBase isn't installed
ENT.Base = "drgbase_nextbot" -- DO NOT TOUCH (obviously)

-- Misc --
ENT.PrintName = "Spook, The 90's Skeleton"
ENT.Category = "Slender Fortress"
ENT.Models = {"models/bots/skeleton_sniper_boss/skeleton_sniper_boss.mdl"}
ENT.BloodColor = BLOOD_COLOR_RED
ENT.CollisionBounds = Vector(8, 8, 41.5)
ENT.RagdollOnDeath = true
ENT.OnIdleSounds={"slender/spook/vox/idle_01.wav","slender/spook/vox/idle_02.wav","slender/spook/vox/idle_03.wav","slender/spook/vox/idle_04.wav","slender/spook/vox/idle_05.wav","slender/spook/vox/idle_06.wav","slender/spook/vox/idle_07.wav","slender/spook/vox/idle_08.wav"}
ENT.IdleSoundDelay = 4
ENT.SpotDuration = 15

-- Stats --
ENT.SpawnHealth = 90000
ENT.ShoveResistance = true
ENT.DamageMultipliers = {}

-- AI --
ENT.MeleeAttackRange = 70
ENT.RangeAttackRange = 1000
ENT.ReachEnemyRange = 70
ENT.AvoidEnemyRange = 0

-- Relationships --
ENT.Factions = {"FACTION_SLENDER"}
ENT.Frightening = true

-- Movements/animations --
ENT.UseWalkframes = false
ENT.WalkAnimation = "run_MELEE"
ENT.RunAnimation = "taunt_conga"
ENT.IdleAnimation = "competitive_loserstate_idle"
ENT.JumpAnimation = "taunt_conga"
ENT.RunSpeed = 400
ENT.WalkSpeed = 85

-- Climbing --
ENT.ClimbLedges = false
ENT.ClimbProps = false
ENT.ClimbLadders = false

-- Detection --
ENT.EyeBone = "head"
ENT.EyeOffset = Vector(10, 0, 1)
ENT.EyeAngle = Angle(0, 0, 0)

-- Possession --
ENT.PossessionEnabled = true
ENT.PossessionMovement = POSSESSION_MOVE_1DIR
ENT.PossessionViews = {
	{
		offset = Vector(0, 15, 15),
		distance = 70
	},
	{
		offset = Vector(7.5, 0, 0),
		distance = 0,
		eyepos = true
	}
}
ENT.PossessionBinds = {
	[IN_ATTACK] = {{
		coroutine = true,
		onkeydown = function(self)
			if self:GetCooldown("NemesisRangeAttack") == 0 then
			self:SetCooldown("NemesisRangeAttack",math.random(1,1))
			self:PlaySequence("AttackStand_Melee_allclass")
			self:Timer(0.3, function()
			self:AttackFunction(65,self.DamageType)
			end)
			end
		end
	}},
	[IN_JUMP] = {{coroutine = true,onkeydown = function(self)self:Jump()end}}
}

if SERVER then
function ENT:AttackFunction(dmg,dmgtype,sndhit)
	if self.Flinching == true then return end
	self:Attack({
		damage = dmg,
		viewpunch = Angle(40, 0, 0),
		type = dmgtype,
		range=self.MeleeAttackRange-math.random(10),
		angle=135,
	}, function(self, hit)
		if self:GetSequenceName(self:GetSequence())=="att4" then return end
		if #hit == 0 then self:EmitSound("weapons/cbar_miss1.wav")return end 
		self:EmitSound("weapons/cbar_hitbod"..math.random(3)..".wav")
	end)
end

function ENT:CustomInitialize()
	self.Flinching = false
	self:SetDefaultRelationship(D_HT, 1)
	self:SetAttack("att1_l", true)
	self:SetCooldown("Twitch",math.random(3,3))
	self:SetCooldown("LightningAttack",math.random(5,5))
	self:SetCooldown("BombAttack",math.random(5,5))
	self:SetModelScale(2)
	self:SetSkin(3)
	self:SetMaterial("models/bots/skeleton/hwn_skeleton_purple")
	self.DoingAttackSoStop = false
	local d = math.random(1,5)
	if d==1 then
	self.IdleAnimation = "competitive_loserstate_idle"
	elseif d==2 then
	self.IdleAnimation = "competitive_winnerstate_idle"
	elseif d==3 then
	self.IdleAnimation = "stand_melee"
	elseif d==4 then
	self.IdleAnimation = "ref"
	elseif d==5 then
	self.IdleAnimation = "stand_loser"
	end
end

function ENT:OnLandOnGround()
	if self:IsDead() then return end
	self:CallInCoroutineOverride(function(self, delay)
		self:PlaySequence("jumpland_MELEE_ALLCLASS")
	end)
end

function ENT:OnSpawn()
	self:EmitSound("weapons/jar_explode.wav")
	ParticleEffect("peejar_impact",self:GetPos()+self:GetUp()*70,Angle(0,0,0),nill)
	ParticleEffect("peejar_impact",self:GetPos()+self:GetUp()*40,Angle(0,0,0),nill)
	ParticleEffect("peejar_impact",self:GetPos(),Angle(0,0,0),nill)
end

function ENT:OnMeleeAttack(enemy)
	local m = math.random(1,2)
	if m==1 then
	self:AttackFunction(150,self.DamageType)
	self:PlaySequenceAndMove("layer_taunt_laugh",2)
	elseif m==2 then
	self:AttackFunction(150,self.DamageType)
	self:PlaySequenceAndMove("layer_taunt04",2)
	end
end
function ENT:OnRangeAttack(enemy)
	local r = math.random(2)
	if r==1 then
	if self:GetCooldown("LightningAttack") == 0 and self.DoingAttackSoStop == false then
		self.DoingAttackSoStop = true
		self.CanAttack = false
		self:SetCooldown("LightningAttack",math.random(15,15))
		self:EmitSound("slender/spook/vox/smite_0"..math.random(3)..".wav")
		self.WalkAnimation = "ref"
		self.RunAnimation = "ref"
		self.IdleAnimation = "ref"
		self.JumpAnimation = "ref"
		self.RunSpeed = 0
		self.WalkSpeed = 0
		self:Timer(1.5, function()
		if self:IsDead() then return end
		self.WalkAnimation = "run_MELEE"
		self.RunAnimation = "taunt_conga"
		self.IdleAnimation = "competitive_loserstate_idle"
		self.JumpAnimation = "taunt_conga"
		self.RunSpeed = 400
		self.WalkSpeed = 85
		self.DoingAttackSoStop = false
		if self:GetHullRangeSquaredTo(enemy) > 1000^2 then return end
		enemy:TakeDamage( 50, self, self )
		ParticleEffect("drg_wrenchmotron_teleport",enemy:GetPos(),Angle(0,0,0),nill)
		enemy:SetVelocity( Vector(0, 0, -1000) )
		self.Wave = ents.Create("prop_combine_ball")
		self.Wave:SetPos(enemy:GetPos())
		self.Wave:SetAngles(enemy:GetAngles())
		self.Wave:Spawn()
		self.Wave:Activate()
		self.Wave:Fire("explode", 0)
		end)
		self.CanAttack = true
	end
	elseif r==2 then
	if self:GetCooldown("BombAttack") == 0 and self.DoingAttackSoStop == false then
		self.DoingAttackSoStop = true
		self:SetCooldown("BombAttack",math.random(15,15))
		self:EmitSound("slender/spook/vox/ignite_0"..math.random(2)..".wav")
		self.WalkAnimation = "ref"
		self.RunAnimation = "ref"
		self.IdleAnimation = "ref"
		self.JumpAnimation = "ref"
		self.RunSpeed = 0
		self.WalkSpeed = 0
		self:Timer(0.1, function()
		local flies = ents.Create("tf_spook_bomb")
		flies:SetPos(self:GetPos()+ self:GetForward()*50 + self:GetUp()*80)
		flies:SetAngles(self:GetAngles())
		flies:Spawn()
		flies:Activate()
		self:DeleteOnRemove(flies)
		local phys = flies:GetPhysicsObject()
		phys:SetVelocity( self:GetAimVector() * 1500 )
		phys:AddAngleVelocity( Vector( math.Rand( -500, 500 ), math.Rand( -500, 500 ), math.Rand( -500, 500 ) ) )
		end)
		self:Timer(0.2, function()
		local flies = ents.Create("tf_spook_bomb")
		flies:SetPos(self:GetPos()+ self:GetForward()*50 + self:GetUp()*80)
		flies:SetAngles(self:GetAngles())
		flies:Spawn()
		flies:Activate()
		self:DeleteOnRemove(flies)
		local phys = flies:GetPhysicsObject()
		phys:SetVelocity( self:GetAimVector() * 1500 )
		phys:AddAngleVelocity( Vector( math.Rand( -500, 500 ), math.Rand( -500, 500 ), math.Rand( -500, 500 ) ) )
		end)
		self:Timer(0.3, function()
		local flies = ents.Create("tf_spook_bomb")
		flies:SetPos(self:GetPos()+ self:GetForward()*50 + self:GetUp()*80)
		flies:SetAngles(self:GetAngles())
		flies:Spawn()
		flies:Activate()
		self:DeleteOnRemove(flies)
		local phys = flies:GetPhysicsObject()
		phys:SetVelocity( self:GetAimVector() * 1500 )
		phys:AddAngleVelocity( Vector( math.Rand( -500, 500 ), math.Rand( -500, 500 ), math.Rand( -500, 500 ) ) )
		end)
		self:Timer(0.4, function()
		local flies = ents.Create("tf_spook_bomb")
		flies:SetPos(self:GetPos()+ self:GetForward()*50 + self:GetUp()*80)
		flies:SetAngles(self:GetAngles())
		flies:Spawn()
		flies:Activate()
		self:DeleteOnRemove(flies)
		local phys = flies:GetPhysicsObject()
		phys:SetVelocity( self:GetAimVector() * 1500 )
		phys:AddAngleVelocity( Vector( math.Rand( -500, 500 ), math.Rand( -500, 500 ), math.Rand( -500, 500 ) ) )
		end)
		self:Timer(0.5, function()
		local flies = ents.Create("tf_spook_bomb")
		flies:SetPos(self:GetPos()+ self:GetForward()*50 + self:GetUp()*80)
		flies:SetAngles(self:GetAngles())
		flies:Spawn()
		flies:Activate()
		self:DeleteOnRemove(flies)
		local phys = flies:GetPhysicsObject()
		phys:SetVelocity( self:GetAimVector() * 1500 )
		phys:AddAngleVelocity( Vector( math.Rand( -500, 500 ), math.Rand( -500, 500 ), math.Rand( -500, 500 ) ) )
		end)
		self:Timer(0.6, function()
		local flies = ents.Create("tf_spook_bomb")
		flies:SetPos(self:GetPos()+ self:GetForward()*50 + self:GetUp()*80)
		flies:SetAngles(self:GetAngles())
		flies:Spawn()
		flies:Activate()
		self:DeleteOnRemove(flies)
		local phys = flies:GetPhysicsObject()
		phys:SetVelocity( self:GetAimVector() * 1500 )
		phys:AddAngleVelocity( Vector( math.Rand( -500, 500 ), math.Rand( -500, 500 ), math.Rand( -500, 500 ) ) )
		end)
		self:Timer(0.7, function()
		local flies = ents.Create("tf_spook_bomb")
		flies:SetPos(self:GetPos()+ self:GetForward()*50 + self:GetUp()*80)
		flies:SetAngles(self:GetAngles())
		flies:Spawn()
		flies:Activate()
		self:DeleteOnRemove(flies)
		local phys = flies:GetPhysicsObject()
		phys:SetVelocity( self:GetAimVector() * 1500 )
		phys:AddAngleVelocity( Vector( math.Rand( -500, 500 ), math.Rand( -500, 500 ), math.Rand( -500, 500 ) ) )
		end)
		self:Timer(0.8, function()
		local flies = ents.Create("tf_spook_bomb")
		flies:SetPos(self:GetPos()+ self:GetForward()*50 + self:GetUp()*80)
		flies:SetAngles(self:GetAngles())
		flies:Spawn()
		flies:Activate()
		self:DeleteOnRemove(flies)
		local phys = flies:GetPhysicsObject()
		phys:SetVelocity( self:GetAimVector() * 1500 )
		phys:AddAngleVelocity( Vector( math.Rand( -500, 500 ), math.Rand( -500, 500 ), math.Rand( -500, 500 ) ) )
		end)
		self:Timer(0.9, function()
		local flies = ents.Create("tf_spook_bomb")
		flies:SetPos(self:GetPos()+ self:GetForward()*50 + self:GetUp()*80)
		flies:SetAngles(self:GetAngles())
		flies:Spawn()
		flies:Activate()
		self:DeleteOnRemove(flies)
		local phys = flies:GetPhysicsObject()
		phys:SetVelocity( self:GetAimVector() * 1500 )
		phys:AddAngleVelocity( Vector( math.Rand( -500, 500 ), math.Rand( -500, 500 ), math.Rand( -500, 500 ) ) )
		end)
		self:Timer(1, function()
		local flies = ents.Create("tf_spook_bomb")
		flies:SetPos(self:GetPos()+ self:GetForward()*50 + self:GetUp()*80)
		flies:SetAngles(self:GetAngles())
		flies:Spawn()
		flies:Activate()
		self:DeleteOnRemove(flies)
		local phys = flies:GetPhysicsObject()
		phys:SetVelocity( self:GetAimVector() * 1500 )
		phys:AddAngleVelocity( Vector( math.Rand( -500, 500 ), math.Rand( -500, 500 ), math.Rand( -500, 500 ) ) )
		end)
		self:Timer(1.1, function()
		local flies = ents.Create("tf_spook_bomb")
		flies:SetPos(self:GetPos()+ self:GetForward()*50 + self:GetUp()*80)
		flies:SetAngles(self:GetAngles())
		flies:Spawn()
		flies:Activate()
		self:DeleteOnRemove(flies)
		local phys = flies:GetPhysicsObject()
		phys:SetVelocity( self:GetAimVector() * 1500 )
		phys:AddAngleVelocity( Vector( math.Rand( -500, 500 ), math.Rand( -500, 500 ), math.Rand( -500, 500 ) ) )
		end)
		self:Timer(1.2, function()
		local flies = ents.Create("tf_spook_bomb")
		flies:SetPos(self:GetPos()+ self:GetForward()*50 + self:GetUp()*80)
		flies:SetAngles(self:GetAngles())
		flies:Spawn()
		flies:Activate()
		self:DeleteOnRemove(flies)
		local phys = flies:GetPhysicsObject()
		phys:SetVelocity( self:GetAimVector() * 1500 )
		phys:AddAngleVelocity( Vector( math.Rand( -500, 500 ), math.Rand( -500, 500 ), math.Rand( -500, 500 ) ) )
		end)
		self:Timer(1.3, function()
		local flies = ents.Create("tf_spook_bomb")
		flies:SetPos(self:GetPos()+ self:GetForward()*50 + self:GetUp()*80)
		flies:SetAngles(self:GetAngles())
		flies:Spawn()
		flies:Activate()
		self:DeleteOnRemove(flies)
		local phys = flies:GetPhysicsObject()
		phys:SetVelocity( self:GetAimVector() * 1500 )
		phys:AddAngleVelocity( Vector( math.Rand( -500, 500 ), math.Rand( -500, 500 ), math.Rand( -500, 500 ) ) )
		end)
		self:Timer(1.4, function()
		local flies = ents.Create("tf_spook_bomb")
		flies:SetPos(self:GetPos()+ self:GetForward()*50 + self:GetUp()*80)
		flies:SetAngles(self:GetAngles())
		flies:Spawn()
		flies:Activate()
		self:DeleteOnRemove(flies)
		local phys = flies:GetPhysicsObject()
		phys:SetVelocity( self:GetAimVector() * 1500 )
		phys:AddAngleVelocity( Vector( math.Rand( -500, 500 ), math.Rand( -500, 500 ), math.Rand( -500, 500 ) ) )
		end)
		self:Timer(1.5, function()
		local flies = ents.Create("tf_spook_bomb")
		flies:SetPos(self:GetPos()+ self:GetForward()*50 + self:GetUp()*80)
		flies:SetAngles(self:GetAngles())
		flies:Spawn()
		flies:Activate()
		self:DeleteOnRemove(flies)
		local phys = flies:GetPhysicsObject()
		phys:SetVelocity( self:GetAimVector() * 1500 )
		phys:AddAngleVelocity( Vector( math.Rand( -500, 500 ), math.Rand( -500, 500 ), math.Rand( -500, 500 ) ) )
		end)
		self:Timer(1.6, function()
		local flies = ents.Create("tf_spook_bomb")
		flies:SetPos(self:GetPos()+ self:GetForward()*50 + self:GetUp()*80)
		flies:SetAngles(self:GetAngles())
		flies:Spawn()
		flies:Activate()
		self:DeleteOnRemove(flies)
		local phys = flies:GetPhysicsObject()
		phys:SetVelocity( self:GetAimVector() * 1500 )
		phys:AddAngleVelocity( Vector( math.Rand( -500, 500 ), math.Rand( -500, 500 ), math.Rand( -500, 500 ) ) )
		end)
		self:Timer(1.7, function()
		local flies = ents.Create("tf_spook_bomb")
		flies:SetPos(self:GetPos()+ self:GetForward()*50 + self:GetUp()*80)
		flies:SetAngles(self:GetAngles())
		flies:Spawn()
		flies:Activate()
		self:DeleteOnRemove(flies)
		local phys = flies:GetPhysicsObject()
		phys:SetVelocity( self:GetAimVector() * 1500 )
		phys:AddAngleVelocity( Vector( math.Rand( -500, 500 ), math.Rand( -500, 500 ), math.Rand( -500, 500 ) ) )
		end)
		self:Timer(1.8, function()
		local flies = ents.Create("tf_spook_bomb")
		flies:SetPos(self:GetPos()+ self:GetForward()*50 + self:GetUp()*80)
		flies:SetAngles(self:GetAngles())
		flies:Spawn()
		flies:Activate()
		self:DeleteOnRemove(flies)
		local phys = flies:GetPhysicsObject()
		phys:SetVelocity( self:GetAimVector() * 1500 )
		phys:AddAngleVelocity( Vector( math.Rand( -500, 500 ), math.Rand( -500, 500 ), math.Rand( -500, 500 ) ) )
		end)
		self:Timer(1.9, function()
		local flies = ents.Create("tf_spook_bomb")
		flies:SetPos(self:GetPos()+ self:GetForward()*50 + self:GetUp()*80)
		flies:SetAngles(self:GetAngles())
		flies:Spawn()
		flies:Activate()
		self:DeleteOnRemove(flies)
		local phys = flies:GetPhysicsObject()
		phys:SetVelocity( self:GetAimVector() * 1500 )
		phys:AddAngleVelocity( Vector( math.Rand( -500, 500 ), math.Rand( -500, 500 ), math.Rand( -500, 500 ) ) )
		end)
		self:Timer(2, function()
		local flies = ents.Create("tf_spook_bomb")
		flies:SetPos(self:GetPos()+ self:GetForward()*50 + self:GetUp()*80)
		flies:SetAngles(self:GetAngles())
		flies:Spawn()
		flies:Activate()
		self:DeleteOnRemove(flies)
		local phys = flies:GetPhysicsObject()
		phys:SetVelocity( self:GetAimVector() * 1500 )
		phys:AddAngleVelocity( Vector( math.Rand( -500, 500 ), math.Rand( -500, 500 ), math.Rand( -500, 500 ) ) )
		self.WalkAnimation = "run_MELEE"
		self.RunAnimation = "taunt_conga"
		self.IdleAnimation = "competitive_loserstate_idle"
		self.JumpAnimation = "taunt_conga"
		self.RunSpeed = 400
		self.WalkSpeed = 85
		self.DoingAttackSoStop = false
		end)
	end
	end
end
-- Damage --
function ENT:OnTakeDamage(dmg)
	if self:GetCooldown("Flinch") == 0 and self.Flinching == false then
	self:CallInCoroutineOverride(function(self, delay)
	self.Flinching = true
	self:EmitSound("slender/spook/vox/stun_0"..math.random(8)..".wav")
	self:PlaySequenceAndWait("layer_PRIMARY_Stun_begin",0.8)
	self:PlaySequenceAndWait("layer_PRIMARY_Stun_end",1)
	self.Flinching = false
	end)
	self:SetCooldown("Flinch",math.random(3.2,6))
	end
end
function ENT:OnPhysDamage(ent, data)
	if string.find(data.HitEntity:GetClass(), "tf_") then return end
	return (data.TheirOldVelocity:Length()*data.HitObject:GetMass())/1000
end
function ENT:_HandleCollide(data)
	if string.find(data.HitEntity:GetClass(), "tf_") then return end
	local ent = data.HitEntity
	if not IsValid(ent) then return end
	local class = ent:GetClass()
	local phys = data.HitObject
	if class == "prop_combine_ball" then
	if self:IsFlagSet(FL_DISSOLVING) then return end
	if not self:OnCombineBall(ent) then
	if not self:IsDead() then
		local dmg = DamageInfo()
		local owner = ent:GetOwner()
		dmg:SetAttacker(IsValid(owner) and owner or ent)
		dmg:SetInflictor(ent)
		dmg:SetDamage(1000)
		dmg:SetDamageType(DMG_DISSOLVE)
		dmg:SetDamageForce(ent:GetVelocity())
		self:TakeDamageInfo(dmg)
	else self:DrG_Dissolve() end
	ent:EmitSound("NPC_CombineBall.KillImpact")
	end
	elseif not ent:IsPlayerHolding() then
	local damage = math.floor(self:OnPhysDamage(ent, data))
	if damage > math.max(0, self.MinPhysDamage) then
		local dmg = DamageInfo()
		if ent:IsVehicle() and IsValid(ent:GetDriver()) then
		dmg:SetAttacker(ent:GetDriver())
		elseif IsValid(ent:GetPhysicsAttacker()) then
		dmg:SetAttacker(ent:GetPhysicsAttacker())
		else dmg:SetAttacker(ent) end
		dmg:SetInflictor(ent)
		dmg:SetDamage(damage)
		if ent:IsVehicle() then
		dmg:SetDamageType(DMG_VEHICLE)
		else dmg:SetDamageType(DMG_CRUSH) end
		dmg:SetDamageForce(phys:GetVelocity())
		self:TakeDamageInfo(dmg)
		end
	end
end
function ENT:OnNewEnemy(enemy)
	self.OnIdleSounds={"slender/spook/vox/chase_01.wav","slender/spook/vox/chase_02.wav","slender/spook/vox/chase_03.wav","slender/spook/vox/chase_04.wav","slender/spook/vox/chase_05.wav"}
	self.IdleSoundDelay = 5
end
function ENT:OnOtherKilled(ent, dmg)
end
function ENT:OnOtherKilled(ent, dmg)
	local attacker = dmg:GetAttacker()
	if IsValid(attacker) and attacker == self then
		if ent:IsPlayer() then
		local p = math.random(1,17)
		if p==1 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." was told a bone joke.")
		elseif p==2 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." questioned if this round was serious.")
		elseif p==3 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." didn't find their death humerous.")
		elseif p==4 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." found their existence not pleasing.")
		elseif p==5 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." died so they can see this death message. If you're reading this, you're a poopy head.")
		elseif p==6 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." tried to annoy Spook.")
		elseif p==7 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." was rekt by Spook.")
		elseif p==8 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." thought Spook wasn't funny.")
		elseif p==9 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." unwillingly joined the skeleton army.")
		elseif p==10 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." called Spook a nerd.")
		elseif p==11 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." found their existance not pleasing by Spook.")
		elseif p==12 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." called Spook 'Spoon Man'.")
		elseif p==13 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." had their cock crushed with a rock.")
		elseif p==14 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." was pissed on untill they dissolved.")
		elseif p==15 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." never felt a skeleton's cold touch.")
		elseif p==16 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." didn't subscribe to his onlyfans.")
		elseif p==17 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." didn't give enough twitch bits.")
		end
		end
		SpookKill1 = "slender/spook/vox/kill_01.wav"
		SpookKill2 = "slender/spook/vox/kill_02.wav"
		SpookKill3 = "slender/spook/vox/kill_03.wav"
		SpookKill4 = "slender/spook/vox/kill_04.wav"
		SpookKill5 = "slender/spook/vox/kill_05.wav"
		SpookKill6 = "slender/spook/vox/kill_06.wav"
		SpookKill7 = "slender/spook/vox/kill_07.wav"
		SpookKill8 = "slender/spook/vox/kill_08.wav"
		local k = math.random(1,8)
		if p==1 then
			local locateplayers = player.GetAll()
			for i = 1, table.getn(locateplayers) do
			locateplayers[i]:ConCommand("play " .. SpookKill1 .. "\n")
			end
		elseif p==2 then
			local locateplayers = player.GetAll()
			for i = 1, table.getn(locateplayers) do
			locateplayers[i]:ConCommand("play " .. SpookKill2 .. "\n")
			end
		elseif p==3 then
			local locateplayers = player.GetAll()
			for i = 1, table.getn(locateplayers) do
			locateplayers[i]:ConCommand("play " .. SpookKill3 .. "\n")
			end
		elseif p==4 then
			local locateplayers = player.GetAll()
			for i = 1, table.getn(locateplayers) do
			locateplayers[i]:ConCommand("play " .. SpookKill4 .. "\n")
			end
		elseif p==5 then
			local locateplayers = player.GetAll()
			for i = 1, table.getn(locateplayers) do
			locateplayers[i]:ConCommand("play " .. SpookKill5 .. "\n")
			end
		elseif p==6 then
			local locateplayers = player.GetAll()
			for i = 1, table.getn(locateplayers) do
			locateplayers[i]:ConCommand("play " .. SpookKill6 .. "\n")
			end
		elseif p==7 then
			local locateplayers = player.GetAll()
			for i = 1, table.getn(locateplayers) do
			locateplayers[i]:ConCommand("play " .. SpookKill7 .. "\n")
			end
		elseif p==8 then
			local locateplayers = player.GetAll()
			for i = 1, table.getn(locateplayers) do
			locateplayers[i]:ConCommand("play " .. SpookKill8 .. "\n")
			end
		end
			self.OnIdleSounds={"slender/spook/vox/idle_01.wav","slender/spook/vox/idle_02.wav","slender/spook/vox/idle_03.wav","slender/spook/vox/idle_04.wav","slender/spook/vox/idle_05.wav","slender/spook/vox/idle_06.wav","slender/spook/vox/idle_07.wav","slender/spook/vox/idle_08.wav"}
			self.IdleSoundDelay = 4
		self:StopSound("slender/golden_skeleton/golden_skeleton_chase.wav")
	end
end

function ENT:OnFatalDamage()return false end
function ENT:OnDeath(dmg)
	self:StopSound("slender/golden_skeleton/golden_skeleton_chase.wav")
end
function ENT:OnRagdoll()
end
function ENT:OnLost()
	self.OnIdleSounds={"slender/spook/vox/idle_01.wav","slender/spook/vox/idle_02.wav","slender/spook/vox/idle_03.wav","slender/spook/vox/idle_04.wav","slender/spook/vox/idle_05.wav","slender/spook/vox/idle_06.wav","slender/spook/vox/idle_07.wav","slender/spook/vox/idle_08.wav"}
	self.IdleSoundDelay = 4
	self:StopSound("slender/golden_skeleton/golden_skeleton_chase.wav")
end
function ENT:OnIdle()
	self:AddPatrolPos(self:RandomPos(1500))
end
function ENT:OnRemove()
	self:EmitSound("weapons/jar_explode.wav")
	ParticleEffect("peejar_impact",self:GetPos()+self:GetUp()*70,Angle(0,0,0),nill)
	ParticleEffect("peejar_impact",self:GetPos()+self:GetUp()*40,Angle(0,0,0),nill)
	ParticleEffect("peejar_impact",self:GetPos(),Angle(0,0,0),nill)
end

function ENT:CustomThink()
	self:RemoveAllDecals()
end
function ENT:OnUpdateAnimation()
	if self:IsDead() then return end
	if !self:IsOnGround() then return self.JumpAnimation, 1
	elseif self:IsRunning() then return self.RunAnimation, self.RunAnimRate
	elseif self:IsMoving() then return self.WalkAnimation, self.WalkAnimRate
	else return self.IdleAnimation, self.IdleAnimRate end
end

function ENT:CallInCoroutineOverride(callback)
	local oldThread = self.BehaveThread
	self.BehaveThread = coroutine.create(function()
		callback(self)
		self.BehaveThread = oldThread
	end)
end
end

-- DO NOT TOUCH --
AddCSLuaFile()
DrGBase.AddNextbot(ENT)