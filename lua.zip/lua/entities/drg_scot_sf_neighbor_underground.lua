if not DrGBase then return end -- return if DrGBase isn't installed
ENT.Base = "drgbase_nextbot" -- DO NOT TOUCH (obviously)

-- Misc --
ENT.PrintName = "The Neighbor (Underground)"
ENT.Category = "Slender Fortress"
ENT.Models = {"models/mentrillum/hello_neighbor/the_neighbor.mdl"}
ENT.BloodColor = BLOOD_COLOR_RED
ENT.CollisionBounds = Vector(35, 35, 166)
ENT.RagdollOnDeath = true
ENT.OnIdleSounds={"slender/neighbor/idle1.wav","slender/neighbor/idle2.wav","slender/neighbor/idle3.wav","slender/neighbor/idle4.wav","slender/neighbor/idle5.wav"}
ENT.IdleSoundDelay = 4
ENT.SpotDuration = 5

-- Stats --
ENT.SpawnHealth = 90000
ENT.ShoveResistance = true
ENT.DamageMultipliers = {}

-- AI --
ENT.MeleeAttackRange = 50
ENT.ReachEnemyRange = 50
ENT.AvoidEnemyRange = 0

-- Relationships --
ENT.Factions = {"FACTION_SLENDER"}
ENT.Frightening = true

-- Movements/animations --
ENT.UseWalkframes = false
ENT.WalkAnimation = "basement_corridor_walk"
ENT.RunAnimation = "basement_corridor_run"
ENT.IdleAnimation = "idle"
ENT.JumpAnimation = "jumploop"
ENT.RunSpeed = 390
ENT.WalkSpeed = 100

-- Climbing --
ENT.ClimbLedges = false
ENT.ClimbProps = false
ENT.ClimbLadders = false

-- Detection --
ENT.EyeBone = "head"
ENT.EyeOffset = Vector(10, 0, 1)
ENT.EyeAngle = Angle(0, 0, 0)

-- Possession --
ENT.PossessionEnabled = true
ENT.PossessionMovement = POSSESSION_MOVE_1DIR
ENT.PossessionViews = {
	{
		offset = Vector(0, 45, 45),
		distance = 170
	},
	{
		offset = Vector(7.5, 0, 0),
		distance = 0,
		eyepos = true
	}
}
ENT.PossessionBinds = {
	[IN_ATTACK] = {{
		coroutine = true,
		onkeydown = function(self)
			self:Timer(0.3, function()
			self:AttackFunction(9999,self.DamageType)
			end)
			self:PlaySequenceAndMove("grabbed2",1,self.PossessionFaceForward)
		end
	}},
	[IN_JUMP] = {{coroutine = true,onkeydown = function(self)self:Jump()end}}
}

if SERVER then
function ENT:AttackFunction(dmg,dmgtype,sndhit)
	if self.Flinching == true then return end
	self:Attack({
		damage = dmg,
		viewpunch = Angle(40, 0, 0),
		type = dmgtype,
		range=self.MeleeAttackRange-math.random(10),
		angle=135,
	}, function(self, hit)
		if self:GetSequenceName(self:GetSequence())=="att4" then return end
		if #hit == 0 then self:EmitSound("")return end 
		self:EmitSound("")
	end)
end

function ENT:CustomInitialize()
	self:SequenceEvent("Crouch_walk_all",{5/9,22/3},self.Step)
	self:SequenceEvent("crouchRUNALL1",{5/9,22/3},self.Step)
	self:SetDefaultRelationship(D_HT, 1)
	self:SetAttack("att1_l", true)
	self:SetCooldown("Twitch",math.random(3,3))
	self:SetCooldown("Flinch",math.random(3.2,6))
	self.Flinching = false
	self.CanSpotAnim = false
	self:SetModelScale(0.5)
	self.DamageType = DMG_DISSOLVE
end

function ENT:OnLandOnGround()
	if self:IsDead() then return end
	self:CallInCoroutineOverride(function(self, delay)
		self:PlaySequenceAndMove("jumpend")
	end)
end

function ENT:Step()
	local p = math.random(1,2)
	if p==1 then
	self:EmitSound("mvm/player/footsteps/robostep_0"..math.random(9)..".wav")
	elseif p==2 then
	self:EmitSound("mvm/player/footsteps/robostep_"..math.random(10,18)..".wav")
	end
end
function ENT:OnSpawn()
	self:EmitSound("ui/item_paper_pickup.wav")
	local effect = ents.Create("drg_scot_sf_neighbor_particles")
	effect:SetPos(self:GetPos())
	effect:SetAngles(self:GetAngles())
	effect:Spawn()
	effect:Activate()
	self:Timer(0.5, function()
		self.CanSpotAnim = true
	end)
end

function ENT:OnMeleeAttack(enemy)
	self:Timer(0.3, function()
	self:AttackFunction(9999,self.DamageType)
	end)
	self:PlaySequenceAndMove("grabbed2",1,self.FaceEnemy)
end
-- Damage --
function ENT:OnTakeDamage(dmg)
	if self:GetCooldown("Flinch") == 0 and self.Flinching == false then
	self:CallInCoroutineOverride(function(self, delay)
	self.Flinching = true
	self:PlaySequenceAndWait("fall_run")
	self.Flinching = false
	end)
	self:SetCooldown("Flinch",math.random(3.2,6))
	end
end
function ENT:OnPhysDamage(ent, data)
	if string.find(data.HitEntity:GetClass(), "tf_") then return end
	return (data.TheirOldVelocity:Length()*data.HitObject:GetMass())/1000
end
function ENT:_HandleCollide(data)
	if string.find(data.HitEntity:GetClass(), "tf_") then return end
	local ent = data.HitEntity
	if not IsValid(ent) then return end
	local class = ent:GetClass()
	local phys = data.HitObject
	if class == "prop_combine_ball" then
	if self:IsFlagSet(FL_DISSOLVING) then return end
	if not self:OnCombineBall(ent) then
	if not self:IsDead() then
		local dmg = DamageInfo()
		local owner = ent:GetOwner()
		dmg:SetAttacker(IsValid(owner) and owner or ent)
		dmg:SetInflictor(ent)
		dmg:SetDamage(1000)
		dmg:SetDamageType(DMG_DISSOLVE)
		dmg:SetDamageForce(ent:GetVelocity())
		self:TakeDamageInfo(dmg)
	else self:DrG_Dissolve() end
	ent:EmitSound("NPC_CombineBall.KillImpact")
	end
	elseif not ent:IsPlayerHolding() then
	local damage = math.floor(self:OnPhysDamage(ent, data))
	if damage > math.max(0, self.MinPhysDamage) then
		local dmg = DamageInfo()
		if ent:IsVehicle() and IsValid(ent:GetDriver()) then
		dmg:SetAttacker(ent:GetDriver())
		elseif IsValid(ent:GetPhysicsAttacker()) then
		dmg:SetAttacker(ent:GetPhysicsAttacker())
		else dmg:SetAttacker(ent) end
		dmg:SetInflictor(ent)
		dmg:SetDamage(damage)
		if ent:IsVehicle() then
		dmg:SetDamageType(DMG_VEHICLE)
		else dmg:SetDamageType(DMG_CRUSH) end
		dmg:SetDamageForce(phys:GetVelocity())
		self:TakeDamageInfo(dmg)
		end
	end
end
function ENT:OnNewEnemy(enemy)
	self.OnIdleSounds={"slender/neighbor/alert1.wav","slender/neighbor/alert2.wav","slender/neighbor/alert3.wav","slender/neighbor/alert4.wav"}
	self.IdleSoundDelay = 4
	self:EmitSound("slender/neighbor/chase_init_"..math.random(8)..".wav",511)
	self:CallInCoroutine(function(self,delay)
		if delay > 0.1 then return end
		self:PlaySequenceAndMove("spotted",1,self.FaceEnemy)
	end)
end
function ENT:OnOtherKilled(ent, dmg)
	local attacker = dmg:GetAttacker()
	if IsValid(attacker) and attacker == self then
		if ent:IsPlayer() then
		local p = math.random(1,4)
		if p==1 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." went missing.")
		elseif p==2 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." will never be heard from again.")
		elseif p==3 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." found out how dark Mr. Peterson's basement actually is.")
		elseif p==4 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." got lost.")
		end
		end
		ent:EmitSound("ui/item_paper_pickup.wav")
		local effect = ents.Create("drg_scot_sf_neighbor_particles")
		effect:SetPos(ent:GetPos())
		effect:SetAngles(ent:GetAngles())
		effect:Spawn()
		effect:Activate()
		PeteKill = "slender/neighbor/kill.wav"
			local locateplayers = player.GetAll()
			for i = 1, table.getn(locateplayers) do
			locateplayers[i]:ConCommand("play " .. PeteKill .. "\n")
			end
		self.OnIdleSounds={"slender/neighbor/idle1.wav","slender/neighbor/idle2.wav","slender/neighbor/idle3.wav","slender/neighbor/idle4.wav","slender/neighbor/idle5.wav"}
		self.IdleSoundDelay = 4
		self:StopSound("slender/duckmedic/chase_music.wav")
	end
end

function ENT:OnFatalDamage()return false end
function ENT:OnDeath(dmg)
	self:StopSound("slender/duckmedic/chase_music.wav")
end
function ENT:OnRagdoll()
end
function ENT:OnLost()
	self.OnIdleSounds={"slender/neighbor/idle1.wav","slender/neighbor/idle2.wav","slender/neighbor/idle3.wav","slender/neighbor/idle4.wav","slender/neighbor/idle5.wav"}
	self.IdleSoundDelay = 4
	self:CallInCoroutine(function(self,delay)
		if delay > 0.1 then return end
		self:PlaySequenceAndMove("failed_attack")
	end)
end
function ENT:OnRemove()
	self:EmitSound("ui/item_paper_pickup.wav")
	local effect = ents.Create("drg_scot_sf_neighbor_particles")
	effect:SetPos(self:GetPos())
	effect:SetAngles(self:GetAngles())
	effect:Spawn()
	effect:Activate()
end

function ENT:CustomThink()
	self:RemoveAllDecals()
end
function ENT:OnUpdateAnimation()
	if self:IsDead() then return end
	if !self:IsOnGround() then return self.JumpAnimation, 1
	elseif self:IsRunning() then return self.RunAnimation, self.RunAnimRate
	elseif self:IsMoving() then return self.WalkAnimation, self.WalkAnimRate
	else return self.IdleAnimation, self.IdleAnimRate end
end

function ENT:CallInCoroutineOverride(callback)
	local oldThread = self.BehaveThread
	self.BehaveThread = coroutine.create(function()
		callback(self)
		self.BehaveThread = oldThread
	end)
end
end

-- DO NOT TOUCH --
AddCSLuaFile()
DrGBase.AddNextbot(ENT)