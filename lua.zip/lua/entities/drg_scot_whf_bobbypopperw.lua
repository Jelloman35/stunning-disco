if not DrGBase then return end -- return if DrGBase isn't installed
ENT.Base = "drgbase_nextbot" -- DO NOT TOUCH (obviously)

-- Misc --
ENT.PrintName = "Bobby Popper (White)"
ENT.Category = "We Happy Few Poppers"
ENT.Models = {"models/scot_sf/BobbyPopper.mdl"}
ENT.BloodColor = DONT_BLEED
ENT.CollisionBounds = Vector(11, 11, 81)
ENT.RagdollOnDeath = false
ENT.Omniscience = false
ENT.MaxYawRate = 0

-- Stats --
ENT.SpawnHealth = 9999999
ENT.ShoveResistance = true
ENT.DamageMultipliers = {}

ENT.SightRange = 0

-- AI --
ENT.MeleeAttackRange = 0
ENT.ReachEnemyRange = 0
ENT.AvoidEnemyRange = 0

-- Relationships --
ENT.Factions = {"FACTION_SLENDER"}
ENT.Frightening = true

-- Movements/animations --
ENT.UseWalkframes = false
ENT.WalkAnimation = "idle"
ENT.RunAnimation = "idle"
ENT.IdleAnimation = "idle"
ENT.JumpAnimation = "idle"
ENT.RunSpeed = 0
ENT.WalkSpeed = 0

-- Climbing --
ENT.ClimbLedges = false
ENT.ClimbProps = false
ENT.ClimbLadders = false

-- Detection --
ENT.EyeBone = "head"
ENT.EyeOffset = Vector(10, 0, 1)
ENT.EyeAngle = Angle(0, 0, 0)

-- Possession --
ENT.PossessionEnabled = false
ENT.PossessionMovement = POSSESSION_MOVE_1DIR
ENT.PossessionViews = {
	{
		offset = Vector(0, 15, 15),
		distance = 70
	},
	{
		offset = Vector(7.5, 0, 0),
		distance = 0,
		eyepos = true
	}
}
ENT.PossessionBinds = {
	[IN_ATTACK] = {{
		coroutine = true,
		onkeydown = function(self)
			if self:GetCooldown("NemesisRangeAttack") == 0 then
			self:SetCooldown("NemesisRangeAttack",math.random(0.6,0.6))
			self:PlaySequence("MELEE_swing")
			self:Timer(0.2, function()
			self:AttackFunction(35,self.DamageType)
			end)
			end
		end
	}},
	[IN_JUMP] = {{coroutine = true,onkeydown = function(self)self:Jump()end}}
}
if SERVER then

function ENT:CustomInitialize()
	self:SetModelScale(1.1)
end

function ENT:OnLandOnGround()
end

function ENT:OnSpawn()
	local col = self:GetCollisionGroup()
	ParticleEffect("crate_drop",self:GetPos(),Angle(0,0,0),nill)
	self:EmitSound("slender/tricky/drit_0"..math.random(0,1)..".wav")
	self:PlaySequenceAndMove("intro")
	self:PlaySequenceAndMove("open")
	self:Timer(0.5, function()
	local bob1 = ents.Create("drg_scot_whf_bobbywhite")
	bob1:SetPos(self:GetPos()+ self:GetForward()*60)
	bob1:SetAngles(self:GetAngles())
	bob1:Spawn()
	bob1:Activate()
	bob1:SetCollisionGroup(COLLISION_GROUP_DEBRIS_TRIGGER)
	bob1:CallInCoroutine(function(bob1, delay)
	bob1:PlaySequenceAndMove("Bobby_Popper_Spawn")
	bob1:GoTo(bob1:LocalToWorld(Vector(120,0,0)),Angle(0,0,0))
	end)
	self:Timer(3, function()
	bob1:SetCollisionGroup(col)
	end)
	end)
	self:Timer(1, function()
	local bob2 = ents.Create("drg_scot_whf_bobbyred")
	bob2:SetPos(self:GetPos()+ self:GetForward()*60)
	bob2:SetAngles(self:GetAngles())
	bob2:Spawn()
	bob2:Activate()
	bob2:SetCollisionGroup(COLLISION_GROUP_DEBRIS_TRIGGER)
	bob2:CallInCoroutine(function(bob2, delay)
	bob2:PlaySequenceAndMove("Bobby_Popper_Spawn")
	bob2:GoTo(bob2:LocalToWorld(Vector(110,70,0)),Angle(0,0,0))
	end)
	self:Timer(3, function()
	bob2:SetCollisionGroup(col)
	end)
	end)
	self:Timer(1.5, function()
	local bob3 = ents.Create("drg_scot_whf_bobbyred")
	bob3:SetPos(self:GetPos()+ self:GetForward()*60)
	bob3:SetAngles(self:GetAngles())
	bob3:Spawn()
	bob3:Activate()
	bob3:SetCollisionGroup(COLLISION_GROUP_DEBRIS_TRIGGER)
	bob3:CallInCoroutine(function(bob3, delay)
	bob3:PlaySequenceAndMove("Bobby_Popper_Spawn")
	bob3:GoTo(bob3:LocalToWorld(Vector(110,-70,0)),Angle(0,0,0))
	end)
	self:Timer(3, function()
	bob3:SetCollisionGroup(col)
	end)
	end)
	self:PlaySequenceAndMove("openidle")
	self:PlaySequenceAndMove("openidle")
	self:PlaySequenceAndMove("openidle")
	self:PlaySequenceAndMove("openidle")
	self:PlaySequenceAndMove("openidle")
	self:PlaySequenceAndMove("openidle")
	self:PlaySequenceAndMove("openidle")
	self:PlaySequenceAndMove("openidle")
	self:PlaySequenceAndMove("openidle")
	self:PlaySequenceAndMove("openidle")
	self:PlaySequenceAndMove("openidle")
	self:PlaySequenceAndMove("openidle")
	self:PlaySequenceAndMove("openidle")
	self:PlaySequenceAndMove("close")
	self:PlaySequenceAndMove("closeidle")
	self:PlaySequenceAndMove("closeidle")
	self:PlaySequenceAndMove("closeidle")
	self:PlaySequenceAndMove("closeidle")
	self:PlaySequenceAndMove("closeidle")
	self:PlaySequenceAndMove("closeidle")
	self:PlaySequenceAndMove("closeidle")
	self:PlaySequenceAndMove("closeidle")
	self:PlaySequenceAndMove("closeidle")
	self:PlaySequenceAndMove("outro")
	ParticleEffect("crate_drop",self:GetPos(),Angle(0,0,0),nill)
	self:EmitSound("slender/tricky/drit_0"..math.random(0,1)..".wav")
	self:Remove()
end

function ENT:OnMeleeAttack(enemy)
end
-- Damage --
function ENT:OnTraceAttack(dmg,dir,tr)
end
function ENT:OnContact(ent)
end
function ENT:OnPhysDamage(ent, data)
	if string.find(data.HitEntity:GetClass(), "tf_") then return end
	return (data.TheirOldVelocity:Length()*data.HitObject:GetMass())/1000
end
function ENT:_HandleCollide(data)
	if string.find(data.HitEntity:GetClass(), "tf_") then return end
	local ent = data.HitEntity
	if not IsValid(ent) then return end
	local class = ent:GetClass()
	local phys = data.HitObject
	if class == "prop_combine_ball" then
	if self:IsFlagSet(FL_DISSOLVING) then return end
	if not self:OnCombineBall(ent) then
	if not self:IsDead() then
		local dmg = DamageInfo()
		local owner = ent:GetOwner()
		dmg:SetAttacker(IsValid(owner) and owner or ent)
		dmg:SetInflictor(ent)
		dmg:SetDamage(1000)
		dmg:SetDamageType(DMG_DISSOLVE)
		dmg:SetDamageForce(ent:GetVelocity())
		self:TakeDamageInfo(dmg)
	else self:DrG_Dissolve() end
	ent:EmitSound("NPC_CombineBall.KillImpact")
	end
	elseif not ent:IsPlayerHolding() then
	local damage = math.floor(self:OnPhysDamage(ent, data))
	if damage > math.max(0, self.MinPhysDamage) then
		local dmg = DamageInfo()
		if ent:IsVehicle() and IsValid(ent:GetDriver()) then
		dmg:SetAttacker(ent:GetDriver())
		elseif IsValid(ent:GetPhysicsAttacker()) then
		dmg:SetAttacker(ent:GetPhysicsAttacker())
		else dmg:SetAttacker(ent) end
		dmg:SetInflictor(ent)
		dmg:SetDamage(damage)
		if ent:IsVehicle() then
		dmg:SetDamageType(DMG_VEHICLE)
		else dmg:SetDamageType(DMG_CRUSH) end
		dmg:SetDamageForce(phys:GetVelocity())
		self:TakeDamageInfo(dmg)
		end
	end
end

function ENT:OnFatalDamage()return false end
function ENT:OnDeath(dmg)
end
function ENT:OnRagdoll()
end

function ENT:CustomThink()self:RemoveAllDecals()end
function ENT:OnUpdateAnimation()
	if self:IsDead() then return end
	if !self:IsOnGround() then return self.JumpAnimation, 1
	elseif self:IsRunning() then return self.RunAnimation, self.RunAnimRate
	elseif self:IsMoving() then return self.WalkAnimation, self.WalkAnimRate
	else return self.IdleAnimation, self.IdleAnimRate end
end

function ENT:CallInCoroutineOverride(callback)
	local oldThread = self.BehaveThread
	self.BehaveThread = coroutine.create(function()
		callback(self)
		self.BehaveThread = oldThread
	end)
end
end

-- DO NOT TOUCH --
AddCSLuaFile()
DrGBase.AddNextbot(ENT)