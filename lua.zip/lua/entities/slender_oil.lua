
AddCSLuaFile();

DEFINE_BASECLASS("base_anim");

ENT.PrintName		= "Gas Can (Arizona)";
ENT.Author			= "Jonascone";
ENT.Information		= "Collectable Slender pages!\nSlender Man+Pages addon required!";
ENT.Category		= "Slender Fortress";

ENT.Editable			= false;
ENT.Spawnable			= true;
ENT.AdminOnly			= false;
ENT.RenderGroup 		= RENDERGROUP_TRANSLUCENT;

local activeGasA = {};

function ENT:SpawnFunction(ply, tr, ClassName)
    // If we're not looking at something, there're already 8 pages, or, we're looking at the ceiling or floor, don't spawn!
	if (table.Count(activeGasA) >= 12) then return NULL; end
    
	local SpawnPos = tr.HitPos + tr.HitNormal - Vector(0, 0, 2);
	local ent = ents.Create(ClassName);
	local i = 0;
    while (i < 12) do
        if (!activeGasA[i]) then
            activeGasA[i] = ent;
            ent:SetSkin(0);
            break;
        end
        i = i + 1;
    end
    ent:SetPos(SpawnPos);
    ent:SetAngles(Angle(0, 0, 0));
	ent:Spawn();
    ent:GetPhysicsObject():EnableMotion(false);
	ent:Activate();
	return ent;	
end

function ENT:Initialize()
    if (CLIENT) then return; end
    self:SetModel(Model("models/props_farm/oilcan02.mdl"));
    self:PhysicsInit(SOLID_VPHYSICS);
    self:SetMoveType(MOVETYPE_VPHYSICS);
    self:SetSolid(SOLID_VPHYSICS); 
    local phys = self:GetPhysicsObject();
    if (phys:IsValid()) then
        phys:Wake();
    end	
end

function ENT:Draw()
    self:DrawModel();
end

function ENT:PrintGasA(ply)    
    ply:PrintMessage(HUD_PRINTCENTER, "Collected " .. ply.numGasA .. " of 12 Gas cans");
end

function ENT:RemoveGasA()
    if (CLIENT) then return; end
    for k, v in pairs(activeGasA) do
        if (v == self) then
            activeGasA[k] = nil;
         end
    end
    self:Remove();
end

function ENT:OnRemove()
    if (CLIENT) then return; end
    self:RemoveGasA();
end
function ENT:Use(ply, caller)
    if (CLIENT or ply:GetEyeTraceNoCursor().Entity != self) then return; end // Only remove the page if the player is aiming at it.
    ply.numGasA = ply.numGasA and ply.numGasA < 12 and ply.numGasA + 1 or 1;
    self:PrintGasA(ply);
    ply:EmitSound(Sound("weapons/gas_can_throw.wav"), 100.0, math.random(100, 100));
    self:RemoveGasA();
end

hook.Add("PreDrawHalos", "SlenderGasAHalo", function()
    halo.Add(ents.FindByClass("slender_oil"), Color(128, 128, 128), 1, 1, 1);
end);