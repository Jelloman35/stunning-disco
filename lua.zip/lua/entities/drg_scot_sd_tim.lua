if not DrGBase then return end -- return if DrGBase isn't installed
ENT.Base = "drgbase_nextbot" -- DO NOT TOUCH (obviously)

-- Misc --
ENT.PrintName = "Eyemorous"
ENT.Category = "STUPENDOUS DISFEATURE"
ENT.Models = {"models/omibox/timor/timor.mdl"}
ENT.BloodColor = BLOOD_COLOR_RED
ENT.CollisionBounds = Vector(14, 14, 83)
ENT.RagdollOnDeath = true
ENT.OnIdleSounds={"slender/timorous/look1.mp3","slender/timorous/look2.mp3","slender/timorous/look3.mp3","slender/timorous/look4.mp3","slender/timorous/look5.mp3","slender/timorous/look6.mp3","slender/timorous/look7.mp3","slender/timorous/look8.mp3"}
ENT.IdleSoundDelay = 3
ENT.SpotDuration = 500

-- Stats --
ENT.SpawnHealth = 90000
ENT.ShoveResistance = true
ENT.DamageMultipliers = {}

-- AI --
ENT.MeleeAttackRange = 50
ENT.ReachEnemyRange = 50
ENT.AvoidEnemyRange = 0

-- Relationships --
ENT.Factions = {"FACTION_SLENDER"}
ENT.Frightening = true

-- Movements/animations --
ENT.UseWalkframes = false
ENT.WalkAnimation = "Crouch_walk_all"
ENT.RunAnimation = "sprint_all"
ENT.IdleAnimation = "timoridle"
ENT.JumpAnimation = "sprint_all"
ENT.RunSpeed = 1400
ENT.WalkSpeed = 60

-- Climbing --
ENT.ClimbLedges = false
ENT.ClimbProps = false
ENT.ClimbLadders = false

-- Detection --
ENT.EyeBone = "head"
ENT.EyeOffset = Vector(10, 0, 1)
ENT.EyeAngle = Angle(0, 0, 0)

-- Possession --
ENT.PossessionEnabled = true
ENT.PossessionMovement = POSSESSION_MOVE_1DIR
ENT.PossessionViews = {
	{
		offset = Vector(0, 15, 15),
		distance = 70
	},
	{
		offset = Vector(7.5, 0, 0),
		distance = 0,
		eyepos = true
	}
}
ENT.PossessionBinds = {
	[IN_ATTACK] = {{
		coroutine = true,
		onkeydown = function(self)
			if self:GetCooldown("NemesisRangeAttack") == 0 then
			self:SetCooldown("NemesisRangeAttack",math.random(1,1))
			self:PlaySequence("AttackStand_Melee_allclass")
			self:Timer(0.3, function()
			self:AttackFunction(65,self.DamageType)
			end)
			end
		end
	}},
	[IN_JUMP] = {{coroutine = true,onkeydown = function(self)self:Jump()end}}
}

if SERVER then
function ENT:AttackFunction(dmg,dmgtype,sndhit)
	self:Attack({
		damage = dmg,
		viewpunch = Angle(40, 0, 0),
		type = dmgtype,
		range=self.MeleeAttackRange-math.random(10),
		angle=135,
	}, function(self, hit)
		if self:GetSequenceName(self:GetSequence())=="att4" then return end
		if #hit == 0 then self:EmitSound("")return end 
		self:EmitSound("")
	end)
end

function ENT:CustomInitialize()
	self.Charges = 0
	self:SetDefaultRelationship(D_NU, 1)
	self:SetAttack("att1_l", true)
	self:SetCooldown("Twitch",math.random(3,3))
	self:SetModelScale(1.1)
	self.LanHelp = ents.Create("obj_re7_bonemerge")
	self.LanHelp:SetModel("models/omibox/timor/timor.mdl")
	self.LanHelp:Spawn()
	self.LanHelp:SetMaterial("Invisible")
	self.LanHelp:DrawShadow(false)
	self.LanHelp:SetParent(self)
	self.LanHelp:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	self.Lantern = ents.Create("obj_re7_bonemerge")
	self.Lantern:SetModel("models/props_halloween/eyeball_projectile.mdl")
	self.Lantern:SetPos(self.LanHelp:GetPos() +self.LanHelp:GetForward() +self.LanHelp:GetRight() +self.LanHelp:GetUp()*-0.5 )
	self.Lantern:SetAngles(self.LanHelp:GetAngles()+Angle(0,0,0))
	self.Lantern:Spawn()
	self.Lantern:SetOwner(self.LanHelp)
	self.Lantern:SetParent(self.LanHelp, 6)
	self.Lantern:AddEffects(bit.bor(EF_FOLLOWBONE))
end
function ENT:HandleAnimEvent(a,b,c,d,e)
	if e == "step" then 
		self:EmitSound("slender/trypo/bigsteppy"..math.random(4)..".mp3")
	end
end

function ENT:OnLandOnGround()
	if self:IsDead() then return end
	self:CallInCoroutineOverride(function(self, delay)
		self:PlaySequence("jumpland_MELEE_ALLCLASS")
	end)
end

function ENT:OnSpawn()
end
function ENT:OnIdle()
end

function ENT:OnMeleeAttack(enemy)
	self:AttackFunction(150,self.DamageType)
end
-- Damage --
function ENT:OnTraceAttack(dmg,dir,tr)
end
function ENT:OnPhysDamage(ent, data)
	if string.find(data.HitEntity:GetClass(), "tf_") then return end
	return (data.TheirOldVelocity:Length()*data.HitObject:GetMass())/1000
end
function ENT:_HandleCollide(data)
	if string.find(data.HitEntity:GetClass(), "tf_") then return end
	local ent = data.HitEntity
	if not IsValid(ent) then return end
	local class = ent:GetClass()
	local phys = data.HitObject
	if class == "prop_combine_ball" then
	if self:IsFlagSet(FL_DISSOLVING) then return end
	if not self:OnCombineBall(ent) then
	if not self:IsDead() then
		local dmg = DamageInfo()
		local owner = ent:GetOwner()
		dmg:SetAttacker(IsValid(owner) and owner or ent)
		dmg:SetInflictor(ent)
		dmg:SetDamage(1000)
		dmg:SetDamageType(DMG_DISSOLVE)
		dmg:SetDamageForce(ent:GetVelocity())
		self:TakeDamageInfo(dmg)
	else self:DrG_Dissolve() end
	ent:EmitSound("NPC_CombineBall.KillImpact")
	end
	elseif not ent:IsPlayerHolding() then
	local damage = math.floor(self:OnPhysDamage(ent, data))
	if damage > math.max(0, self.MinPhysDamage) then
		local dmg = DamageInfo()
		if ent:IsVehicle() and IsValid(ent:GetDriver()) then
		dmg:SetAttacker(ent:GetDriver())
		elseif IsValid(ent:GetPhysicsAttacker()) then
		dmg:SetAttacker(ent:GetPhysicsAttacker())
		else dmg:SetAttacker(ent) end
		dmg:SetInflictor(ent)
		dmg:SetDamage(damage)
		if ent:IsVehicle() then
		dmg:SetDamageType(DMG_VEHICLE)
		else dmg:SetDamageType(DMG_CRUSH) end
		dmg:SetDamageForce(phys:GetVelocity())
		self:TakeDamageInfo(dmg)
		end
	end
end
function ENT:OnNewEnemy(enemy)
	self:EmitSound("slender/timorous/engage.mp3",511)
end
function ENT:OnOtherKilled(ent, dmg)
	local attacker = dmg:GetAttacker()
	if IsValid(attacker) and attacker == self then
		if ent:IsPlayer() then
		local p = math.random(1,2)
		if p==1 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." Was Spooped By Eyemorus.")
		elseif p==2 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." Was Spooked By Eyemorus.")
		end
		end
		self:AddEntityRelationship( ent, D_NU, 99 )
		self.Charges = 0
		TimKill = "slender/timorous/scare3.mp3"
			local locateplayers = player.GetAll()
			for i = 1, table.getn(locateplayers) do
			locateplayers[i]:ConCommand("play " .. TimKill .. "\n")
			end
		self.CanRunAfterYoAss = false
		self:StopSound("slender/duckmedic/chase_music.wav")
	end
end

function ENT:OnFatalDamage()return false end
function ENT:OnDeath(dmg)
	self:StopSound("slender/duckmedic/chase_music.wav")
end
function ENT:OnRagdoll()
end
function ENT:OnRemove()
end

function ENT:CustomThink()
	self:RemoveAllDecals()
for k,v in pairs(ents.GetAll()) do
if v:IsPlayer() then
if self:Visible(v) and self:Disposition(v) != D_LI and v:Alive() and v:IsFlagSet(FL_NOTARGET) != true and GetConVarNumber("ai_ignoreplayers") == 0 then


self.Charges = math.min(300,self.Charges + 1)


if self.Charges == 299 then
self:AddEntityRelationship( v, D_HT, 99 )
self:SpotEntity(v)

end


end
end
end
for k,v in pairs(ents.GetAll()) do
if v:IsNPC() then
if self:Visible(v) and self:Disposition(v) != D_LI and IsValid(v) and v:IsFlagSet(FL_NOTARGET) != true then


self.Charges = math.min(300,self.Charges + 1)


if self.Charges == 299 then
self:AddEntityRelationship( v, D_HT, 99 )
self:SpotEntity(v)

end


end
end
end
end
function ENT:OnUpdateAnimation()
	if self:IsDead() then return end
	if !self:IsOnGround() then return self.JumpAnimation, 1
	elseif self:IsRunning() then return self.RunAnimation, self.RunAnimRate
	elseif self:IsMoving() then return self.WalkAnimation, self.WalkAnimRate
	else return self.IdleAnimation, self.IdleAnimRate end
end

function ENT:CallInCoroutineOverride(callback)
	local oldThread = self.BehaveThread
	self.BehaveThread = coroutine.create(function()
		callback(self)
		self.BehaveThread = oldThread
	end)
end
end

-- DO NOT TOUCH --
AddCSLuaFile()
DrGBase.AddNextbot(ENT)