if not DrGBase then return end -- return if DrGBase isn't installed
ENT.Base = "drgbase_nextbot" -- DO NOT TOUCH (obviously)

-- Misc --
ENT.PrintName = "Kek Doctor"
ENT.Category = "Twitter HQ"
ENT.Models = {"models/scot_sf/joydoctor/joydoctor.mdl"}
ENT.BloodColor = BLOOD_COLOR_RED
ENT.CollisionBounds = Vector(11.66666666666667, 11.66666666666667, 69.16666666666667)
ENT.RagdollOnDeath = true
ENT.OnIdleSounds={"slender/joydoc/idle1.wav","slender/joydoc/idle2.wav"}
ENT.IdleSoundDelay = 4
ENT.SpotDuration = 30

-- Stats --
ENT.SpawnHealth = 100
ENT.ShoveResistance = true
ENT.DamageMultipliers = {}

-- AI --
ENT.MeleeAttackRange = 50
ENT.ReachEnemyRange = 50
ENT.AvoidEnemyRange = 0

-- Relationships --
ENT.Factions = {"FACTION_TWITTER"}
ENT.Frightening = false

-- Movements/animations --
ENT.UseWalkframes = false
ENT.WalkAnimation = "Doctor_Walk"
ENT.RunAnimation = "Doctor_Run"
ENT.IdleAnimation = "timoridle"
ENT.JumpAnimation = "Doctor_Run"
ENT.RunSpeed = 400
ENT.WalkSpeed = 30

-- Climbing --
ENT.ClimbLedges = false
ENT.ClimbProps = false
ENT.ClimbLadders = false

-- Detection --
ENT.EyeBone = "head"
ENT.EyeOffset = Vector(10, 0, 1)
ENT.EyeAngle = Angle(0, 0, 0)

-- Possession --
ENT.PossessionEnabled = false
ENT.PossessionMovement = POSSESSION_MOVE_1DIR
ENT.PossessionViews = {
	{
		offset = Vector(0, 15, 15),
		distance = 70
	},
	{
		offset = Vector(7.5, 0, 0),
		distance = 0,
		eyepos = true
	}
}
ENT.PossessionBinds = {
	[IN_ATTACK] = {{
		coroutine = true,
		onkeydown = function(self)
			if self:GetCooldown("NemesisRangeAttack") == 0 then
			self:SetCooldown("NemesisRangeAttack",math.random(1,1))
			self:PlaySequence("AttackStand_Melee_allclass")
			self:Timer(0.3, function()
			self:AttackFunction(65,self.DamageType)
			end)
			end
		end
	}},
	[IN_JUMP] = {{coroutine = true,onkeydown = function(self)self:Jump()end}}
}

if SERVER then
function ENT:AttackFunction(dmg,dmgtype,sndhit)
	if self.Flinching == true or self:IsDead() then return end
	self:Attack({
		damage = dmg,
		viewpunch = Angle(40, 0, 0),
		type = dmgtype,
		range=self.MeleeAttackRange-math.random(10),
		angle=135,
	}, function(self, hit)
		if self:GetSequenceName(self:GetSequence())=="att4" then return end
		if #hit == 0 then self:EmitSound("weapons/cbar_miss1.wav")return end 
		self:EmitSound("slender/cjessie/hit.wav")
	end)
end

function ENT:CustomInitialize()
	self.Flinching = false
	self.Charges = 0
	self:SetDefaultRelationship(D_HT, 1)
	self:SetAttack("att1_l", true)
	self:SetCooldown("Twitch",math.random(3,3))
	self:SetCooldown("Flinch",math.random(3.2,6))
	self:SetSkin(math.random(1,5))
	self:SetSubMaterial(2, "spazter/paint_colors/normal/an_air_of_debonair_BLU")
	self:SetSubMaterial(3, "spazter/paint_colors/normal/team_spirit_BLU")
	self:SetSubMaterial(5, "spazter/paint_colors/normal/operators_overalls_BLU")
	self:SetModelScale(1.19)
	local d = math.random(1,2)
	if d==1 then
	self.IdleAnimation = "Doctor_Idle1"
	elseif d==2 then
	self.IdleAnimation = "Doctor_Idle2"
	end
end
function ENT:OnIdle()
end
function ENT:Step()
	self:EmitSound("slender/wehappyfew/bobby_step"..math.random(2)..".wav")
end

function ENT:OnLandOnGround()
	if self:IsDead() then return end
	self:CallInCoroutineOverride(function(self, delay)
		self:PlaySequence("jumpland_MELEE_ALLCLASS")
	end)
end

function ENT:OnSpawn()
end

function ENT:OnMeleeAttack(enemy)
	self:Timer(0.3, function()
	self:AttackFunction(20,self.DamageType)
	end)
	self:PlaySequenceAndMove("Doctor_Attack",1,self.FaceEnemy)
end
-- Damage --
function ENT:OnTakeDamage(dmg)
end
function ENT:OnPhysDamage(ent, data)
	if string.find(data.HitEntity:GetClass(), "tf_") then return end
	return (data.TheirOldVelocity:Length()*data.HitObject:GetMass())/1000
end
function ENT:_HandleCollide(data)
	if string.find(data.HitEntity:GetClass(), "tf_") then return end
	local ent = data.HitEntity
	if not IsValid(ent) then return end
	local class = ent:GetClass()
	local phys = data.HitObject
	if class == "prop_combine_ball" then
	if self:IsFlagSet(FL_DISSOLVING) then return end
	if not self:OnCombineBall(ent) then
	if not self:IsDead() then
		local dmg = DamageInfo()
		local owner = ent:GetOwner()
		dmg:SetAttacker(IsValid(owner) and owner or ent)
		dmg:SetInflictor(ent)
		dmg:SetDamage(1000)
		dmg:SetDamageType(DMG_DISSOLVE)
		dmg:SetDamageForce(ent:GetVelocity())
		self:TakeDamageInfo(dmg)
	else self:DrG_Dissolve() end
	ent:EmitSound("NPC_CombineBall.KillImpact")
	end
	elseif not ent:IsPlayerHolding() then
	local damage = math.floor(self:OnPhysDamage(ent, data))
	if damage > math.max(0, self.MinPhysDamage) then
		local dmg = DamageInfo()
		if ent:IsVehicle() and IsValid(ent:GetDriver()) then
		dmg:SetAttacker(ent:GetDriver())
		elseif IsValid(ent:GetPhysicsAttacker()) then
		dmg:SetAttacker(ent:GetPhysicsAttacker())
		else dmg:SetAttacker(ent) end
		dmg:SetInflictor(ent)
		dmg:SetDamage(damage)
		if ent:IsVehicle() then
		dmg:SetDamageType(DMG_VEHICLE)
		else dmg:SetDamageType(DMG_CRUSH) end
		dmg:SetDamageForce(phys:GetVelocity())
		self:TakeDamageInfo(dmg)
		end
	end
end
function ENT:OnNewEnemy(enemy)
	if self.Flinching == true or self:IsDead() then return end
	self:EmitSound("slender/joydoc/alert1.wav",511)
	self.OnIdleSounds={""}
	self.IdleSoundDelay = 0
	for k,v in pairs(ents.FindByClass("drg_scot_whf_twobby")) do
	if self:GetPos():Distance(v:GetPos()) < 450 and v:IsAlive() and self:IsAlive() then
	v:AddEntityRelationship( enemy, D_HT, 99 )
	v:FaceInstant(enemy)
	else
	end
	end
	for k,v in pairs(ents.FindByClass("drg_scot_whf_kekdoc")) do
	if self:GetPos():Distance(v:GetPos()) < 450 and v:IsAlive() and self:IsAlive() then
	v:AddEntityRelationship( enemy, D_HT, 99 )
	v:FaceInstant(enemy)
	else
	end
	end
end
function ENT:OnOtherKilled(ent, dmg)
	local attacker = dmg:GetAttacker()
	if IsValid(attacker) and attacker == self then
		if ent:IsPlayer() then
		local m = math.random(1,5)
		if m==1 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." Was Off Their Joy.")
		elseif m==2 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." Is a Downer.")
		elseif m==3 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." Was Stopped From Spreading Downer Propaganda.")
		elseif m==4 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." Got Put Back On Joy.")
		elseif m==5 then
		PrintMessage(HUD_PRINTTALK, ent:Name().." Was Nicely Put Back On Joy.")
		end
		end
		self.CanRunAfterYoAss = false
		self:StopSound("slender/duckmedic/chase_music.wav")
		self.OnIdleSounds={"slender/joydoc/idle1.wav","slender/joydoc/idle2.wav"}
		self.IdleSoundDelay = 4
	end
end
function ENT:OnLostEntity(ent)
	self:AddEntityRelationship( ent, D_NU, 99 )
end
function ENT:OnLost()
	local d = math.random(1,2)
	if d==1 then
	self.IdleAnimation = "Doctor_Idle1"
	elseif d==2 then
	self.IdleAnimation = "Doctor_Idle2"
	end
	self.Charges = 0
	self.OnIdleSounds={"slender/joydoc/idle1.wav","slender/joydoc/idle2.wav"}
	self.IdleSoundDelay = 4
end

function ENT:OnFatalDamage()return false end
function ENT:OnDeath(dmg)
	self:SetCollisionBounds( Vector (-11, -11, 0), Vector (11, 11, 5) )
	self:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
	self.OnIdleSounds={""}
	self:StopSound("slender/duckmedic/chase_music.wav")
	SafeRemoveEntityDelayed(self,80)
	self:PlaySequenceAndMove("doctor_death")
	self:PauseCoroutine(false)
end
function ENT:OnRagdoll()
end
function ENT:OnRemove()
end

function ENT:CustomThink()
	self:RemoveAllDecals()
	if self:IsDead() then
	self.OnIdleSounds={""}
	end
end
function ENT:OnUpdateAnimation()
	if self:IsDead() then return end
	if !self:IsOnGround() then return self.JumpAnimation, 1
	elseif self:IsRunning() then return self.RunAnimation, self.RunAnimRate
	elseif self:IsMoving() then return self.WalkAnimation, self.WalkAnimRate
	else return self.IdleAnimation, self.IdleAnimRate end
end

function ENT:CallInCoroutineOverride(callback)
	local oldThread = self.BehaveThread
	self.BehaveThread = coroutine.create(function()
		callback(self)
		self.BehaveThread = oldThread
	end)
end
end

-- DO NOT TOUCH --
AddCSLuaFile()
DrGBase.AddNextbot(ENT)