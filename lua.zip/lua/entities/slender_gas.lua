
AddCSLuaFile();

DEFINE_BASECLASS("base_anim");

ENT.PrintName		= "Gas Can";
ENT.Author			= "Jonascone";
ENT.Information		= "Collectable Slender pages!\nSlender Man+Pages addon required!";
ENT.Category		= "Slender Fortress";

ENT.Editable			= false;
ENT.Spawnable			= true;
ENT.AdminOnly			= false;
ENT.RenderGroup 		= RENDERGROUP_TRANSLUCENT;

local activeGas = {};

function ENT:SpawnFunction(ply, tr, ClassName)
    // If we're not looking at something, there're already 8 pages, or, we're looking at the ceiling or floor, don't spawn!
	if (table.Count(activeGas) >= 8) then return NULL; end
    
	local SpawnPos = tr.HitPos + tr.HitNormal - Vector(0, 0, 2);
	local ent = ents.Create(ClassName);
	local i = 0;
    while (i < 8) do
        if (!activeGas[i]) then
            activeGas[i] = ent;
            ent:SetSkin(0);
            break;
        end
        i = i + 1;
    end
    ent:SetPos(SpawnPos);
    ent:SetAngles(Angle(0, 0, 0));
	ent:Spawn();
    ent:GetPhysicsObject():EnableMotion(false);
	ent:Activate();
	return ent;	
end

function ENT:Initialize()
    if (CLIENT) then return; end
    self:SetModel(Model("models/props_farm/oilcan01b.mdl"));
    self:PhysicsInit(SOLID_VPHYSICS);
    self:SetMoveType(MOVETYPE_VPHYSICS);
    self:SetSolid(SOLID_VPHYSICS); 
    local phys = self:GetPhysicsObject();
    if (phys:IsValid()) then
        phys:Wake();
    end	
end

function ENT:Draw()
    self:DrawModel();
end

function ENT:PrintGas(ply)    
    ply:PrintMessage(HUD_PRINTCENTER, "Collected " .. ply.numGas .. " of 8 Gas cans");
end

function ENT:RemoveGas()
    if (CLIENT) then return; end
    for k, v in pairs(activeGas) do
        if (v == self) then
            activeGas[k] = nil;
         end
    end
    self:Remove();
end

function ENT:OnRemove()
    if (CLIENT) then return; end
    self:RemoveGas();
end
function ENT:Use(ply, caller)
    if (CLIENT or ply:GetEyeTraceNoCursor().Entity != self) then return; end // Only remove the page if the player is aiming at it.
    ply.numGas = ply.numGas and ply.numGas < 8 and ply.numGas + 1 or 1;
    self:PrintGas(ply);
    ply:EmitSound(Sound("weapons/gas_can_throw.wav"), 100.0, math.random(100, 100));
    self:RemoveGas();
end

hook.Add("PreDrawHalos", "SlenderGasHalo", function()
    halo.Add(ents.FindByClass("slender_gas"), Color(128, 128, 128), 1, 1, 1);
end);