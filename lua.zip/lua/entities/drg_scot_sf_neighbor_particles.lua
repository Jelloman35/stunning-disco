if not DrGBase then return end -- return if DrGBase isn't installed
ENT.Base = "drgbase_nextbot" -- DO NOT TOUCH (obviously)

-- Misc --
ENT.Models = {"models/props_lab/huladoll.mdl"}
ENT.BloodColor = DONT_BLEED
ENT.CollisionBounds = Vector(1, 1, 1)
ENT.RagdollOnDeath = false
ENT.Omniscience = false

-- Stats --
ENT.SpawnHealth = 9999999
ENT.ShoveResistance = true
ENT.DamageMultipliers = {}

ENT.SightRange = 0

-- AI --
ENT.MeleeAttackRange = 0
ENT.ReachEnemyRange = 0
ENT.AvoidEnemyRange = 0

-- Relationships --
ENT.Factions = {"FACTION_SLENDER"}
ENT.Frightening = true

-- Movements/animations --
ENT.UseWalkframes = false
ENT.WalkAnimation = "idle"
ENT.RunAnimation = "idle"
ENT.IdleAnimation = "idle"
ENT.JumpAnimation = "idle"
ENT.RunSpeed = 0
ENT.WalkSpeed = 0

-- Climbing --
ENT.ClimbLedges = false
ENT.ClimbProps = false
ENT.ClimbLadders = false

-- Detection --
ENT.EyeBone = "head"
ENT.EyeOffset = Vector(10, 0, 1)
ENT.EyeAngle = Angle(0, 0, 0)

-- Possession --
ENT.PossessionEnabled = false
ENT.PossessionMovement = POSSESSION_MOVE_1DIR
ENT.PossessionViews = {
	{
		offset = Vector(0, 15, 15),
		distance = 70
	},
	{
		offset = Vector(7.5, 0, 0),
		distance = 0,
		eyepos = true
	}
}
ENT.PossessionBinds = {
	[IN_ATTACK] = {{
		coroutine = true,
		onkeydown = function(self)
			if self:GetCooldown("NemesisRangeAttack") == 0 then
			self:SetCooldown("NemesisRangeAttack",math.random(0.6,0.6))
			self:PlaySequence("MELEE_swing")
			self:Timer(0.2, function()
			self:AttackFunction(35,self.DamageType)
			end)
			end
		end
	}},
	[IN_JUMP] = {{coroutine = true,onkeydown = function(self)self:Jump()end}}
}
if SERVER then

function ENT:CustomInitialize()
	self.Lantern1 = ents.Create("obj_re7_bonemerge")
	self.Lantern1:SetModel("models/props_lab/huladoll.mdl")
	self.Lantern1:SetPos(self:GetPos() +self:GetForward() +self:GetRight() +self:GetUp()*10 )
	self.Lantern1:SetAngles(self:GetAngles()+Angle(0,0,0))
	self.Lantern1:Spawn()
	self.Lantern1:SetModelScale(0.1)
	self.Lantern1:SetMaterial("Invisible")
	self.Lantern1:SetOwner(self)
	self.Lantern1:SetParent(self, 0)
	self.Lantern1:AddEffects(bit.bor(EF_FOLLOWBONE))
	self.Lantern2 = ents.Create("obj_re7_bonemerge")
	self.Lantern2:SetModel("models/props_lab/huladoll.mdl")
	self.Lantern2:SetPos(self:GetPos() +self:GetForward() +self:GetRight() +self:GetUp()*20 )
	self.Lantern2:SetAngles(self:GetAngles()+Angle(0,0,0))
	self.Lantern2:Spawn()
	self.Lantern2:SetModelScale(0.1)
	self.Lantern2:SetMaterial("Invisible")
	self.Lantern2:SetOwner(self)
	self.Lantern2:SetParent(self, 0)
	self.Lantern2:AddEffects(bit.bor(EF_FOLLOWBONE))
	self.Lantern3 = ents.Create("obj_re7_bonemerge")
	self.Lantern3:SetModel("models/props_lab/huladoll.mdl")
	self.Lantern3:SetPos(self:GetPos() +self:GetForward() +self:GetRight() +self:GetUp()*30 )
	self.Lantern3:SetAngles(self:GetAngles()+Angle(0,0,0))
	self.Lantern3:Spawn()
	self.Lantern3:SetModelScale(0.1)
	self.Lantern3:SetMaterial("Invisible")
	self.Lantern3:SetOwner(self)
	self.Lantern3:SetParent(self, 0)
	self.Lantern3:AddEffects(bit.bor(EF_FOLLOWBONE))
	self.Lantern4 = ents.Create("obj_re7_bonemerge")
	self.Lantern4:SetModel("models/props_lab/huladoll.mdl")
	self.Lantern4:SetPos(self:GetPos() +self:GetForward() +self:GetRight() +self:GetUp()*40 )
	self.Lantern4:SetAngles(self:GetAngles()+Angle(0,0,0))
	self.Lantern4:Spawn()
	self.Lantern4:SetModelScale(0.1)
	self.Lantern4:SetMaterial("Invisible")
	self.Lantern4:SetOwner(self)
	self.Lantern4:SetParent(self, 0)
	self.Lantern4:AddEffects(bit.bor(EF_FOLLOWBONE))
	self.Lantern5 = ents.Create("obj_re7_bonemerge")
	self.Lantern5:SetModel("models/props_lab/huladoll.mdl")
	self.Lantern5:SetPos(self:GetPos() +self:GetForward() +self:GetRight() +self:GetUp()*50 )
	self.Lantern5:SetAngles(self:GetAngles()+Angle(0,0,0))
	self.Lantern5:Spawn()
	self.Lantern5:SetMaterial("Invisible")
	self.Lantern5:SetOwner(self)
	self.Lantern5:SetModelScale(0.1)
	self.Lantern5:SetParent(self, 0)
	self.Lantern5:AddEffects(bit.bor(EF_FOLLOWBONE))
	self.Lantern6 = ents.Create("obj_re7_bonemerge")
	self.Lantern6:SetModel("models/props_lab/huladoll.mdl")
	self.Lantern6:SetPos(self:GetPos() +self:GetForward() +self:GetRight() +self:GetUp()*60 )
	self.Lantern6:SetAngles(self:GetAngles()+Angle(0,0,0))
	self.Lantern6:Spawn()
	self.Lantern6:SetMaterial("Invisible")
	self.Lantern6:SetOwner(self)
	self.Lantern6:SetModelScale(0.1)
	self.Lantern6:SetParent(self, 0)
	self.Lantern6:AddEffects(bit.bor(EF_FOLLOWBONE))
	self:LightOn()
	self:SetModelScale(0.1)
	self:SetMaterial("Invisible")
	self:SetRenderFX(15)
	self:SetColor(Color(0,0,0,0))
	self.Lantern1:SetRenderFX(15)
	self.Lantern2:SetRenderFX(15)
	self.Lantern3:SetRenderFX(15)
	self.Lantern4:SetRenderFX(15)
	self.Lantern5:SetRenderFX(15)
	self.Lantern6:SetRenderFX(15)
	self.Lantern1:SetColor(Color(0,0,0,0))
	self.Lantern2:SetColor(Color(0,0,0,0))
	self.Lantern3:SetColor(Color(0,0,0,0))
	self.Lantern4:SetColor(Color(0,0,0,0))
	self.Lantern5:SetColor(Color(0,0,0,0))
	self.Lantern6:SetColor(Color(0,0,0,0))
	self:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
	self:Timer(2, function()
	SafeRemoveEntity(self)
	end)
end

function ENT:OnLandOnGround()
end
function ENT:LightOn()
	ParticleEffectAttach("player_intel_papertrail",PATTACH_POINT_FOLLOW,self.Lantern1,0)
	ParticleEffectAttach("player_intel_papertrail",PATTACH_POINT_FOLLOW,self.Lantern2,0)
	ParticleEffectAttach("player_intel_papertrail",PATTACH_POINT_FOLLOW,self.Lantern3,0)
	ParticleEffectAttach("player_intel_papertrail",PATTACH_POINT_FOLLOW,self.Lantern4,0)
	ParticleEffectAttach("player_intel_papertrail",PATTACH_POINT_FOLLOW,self.Lantern5,0)
	ParticleEffectAttach("player_intel_papertrail",PATTACH_POINT_FOLLOW,self.Lantern6,0)
end

function ENT:OnSpawn()
end

function ENT:OnRemove()
	self:StopParticles()
end

function ENT:OnMeleeAttack(enemy)
end
-- Damage --
function ENT:OnTraceAttack(dmg,dir,tr)
end
function ENT:OnContact(ent)
end
function ENT:OnPhysDamage(ent, data)
	if string.find(data.HitEntity:GetClass(), "tf_") then return end
	return (data.TheirOldVelocity:Length()*data.HitObject:GetMass())/1000
end
function ENT:_HandleCollide(data)
	if string.find(data.HitEntity:GetClass(), "tf_") then return end
	local ent = data.HitEntity
	if not IsValid(ent) then return end
	local class = ent:GetClass()
	local phys = data.HitObject
	if class == "prop_combine_ball" then
	if self:IsFlagSet(FL_DISSOLVING) then return end
	if not self:OnCombineBall(ent) then
	if not self:IsDead() then
		local dmg = DamageInfo()
		local owner = ent:GetOwner()
		dmg:SetAttacker(IsValid(owner) and owner or ent)
		dmg:SetInflictor(ent)
		dmg:SetDamage(1000)
		dmg:SetDamageType(DMG_DISSOLVE)
		dmg:SetDamageForce(ent:GetVelocity())
		self:TakeDamageInfo(dmg)
	else self:DrG_Dissolve() end
	ent:EmitSound("NPC_CombineBall.KillImpact")
	end
	elseif not ent:IsPlayerHolding() then
	local damage = math.floor(self:OnPhysDamage(ent, data))
	if damage > math.max(0, self.MinPhysDamage) then
		local dmg = DamageInfo()
		if ent:IsVehicle() and IsValid(ent:GetDriver()) then
		dmg:SetAttacker(ent:GetDriver())
		elseif IsValid(ent:GetPhysicsAttacker()) then
		dmg:SetAttacker(ent:GetPhysicsAttacker())
		else dmg:SetAttacker(ent) end
		dmg:SetInflictor(ent)
		dmg:SetDamage(damage)
		if ent:IsVehicle() then
		dmg:SetDamageType(DMG_VEHICLE)
		else dmg:SetDamageType(DMG_CRUSH) end
		dmg:SetDamageForce(phys:GetVelocity())
		self:TakeDamageInfo(dmg)
		end
	end
end

function ENT:OnFatalDamage()return false end
function ENT:OnDeath(dmg)
end
function ENT:OnRagdoll()
end

function ENT:CustomThink()self:RemoveAllDecals()end
function ENT:OnUpdateAnimation()
	if self:IsDead() then return end
	if !self:IsOnGround() then return self.JumpAnimation, 1
	elseif self:IsRunning() then return self.RunAnimation, self.RunAnimRate
	elseif self:IsMoving() then return self.WalkAnimation, self.WalkAnimRate
	else return self.IdleAnimation, self.IdleAnimRate end
end

function ENT:CallInCoroutineOverride(callback)
	local oldThread = self.BehaveThread
	self.BehaveThread = coroutine.create(function()
		callback(self)
		self.BehaveThread = oldThread
	end)
end
end

-- DO NOT TOUCH --
AddCSLuaFile()
DrGBase.AddNextbot(ENT)