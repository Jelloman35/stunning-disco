if not DrGBase then return end -- return if DrGBase isn't installed
ENT.Base = "drgbase_nextbot" -- DO NOT TOUCH (obviously)

-- Misc --
ENT.PrintName = "Seeker"
ENT.Category = "Slender Fortress"
ENT.Models = {"models/joe/seeker.mdl"}
ENT.BloodColor = BLOOD_COLOR_RED

-- Relationships --
ENT.Factions = {"FACTION_GREENFLU"}

-- Stats --
ENT.SpawnHealth = 9999999

-- AI --
ENT.MeleeAttackRange = 50
ENT.RangeAttackRange = 200
ENT.ReachEnemyRange = 50
ENT.AvoidEnemyRange = 0
ENT.FollowPlayers = true

-- Detection --
ENT.EyeBone = "ValveBiped.Bip01_Head1"
ENT.EyeOffset = Vector(7.5, 0, 5)
ENT.EyeAngle = Angle(0, 0, 0)

-- Possession --
ENT.PossessionEnabled = false
ENT.PossessionViews = {
  {
    offset = Vector(0, 30, 30),
    distance = 100
  },
  {
    offset = Vector(1.5, 1, -3),
    distance = 0,
    eyepos = true
  }
}
ENT.PossessionBinds = {
	[IN_ATTACK] = {{coroutine = true,onkeydown = function(self)
		if self:GetCooldown("Melee") == 0 then
		self:SetCooldown("Melee",math.random(1.5,1.5))
		self:PlaySequence("Run_Shoot_KNIFE")
		self:Timer(0.4, function()
			self:Attack({
				damage = 4,
				type = DMG_SLASH,
				viewpunch = Angle(20, math.random(-10, 10), 0),
			}, 
			function(self, hit)
				if #hit == 0 then self:EmitSound("vj_l4d_com/attack_miss/claw_miss_"..math.random(2)..".wav")return end 
				self:EmitSound("vj_l4d2/hit/claw_hit_flesh_"..math.random(4)..".mp3")
			end)
		end)
		end
	end}},
	[IN_ATTACK2] = {{coroutine = true,onkeydown = function(self)
		if self:GetCooldown("Puke") == 0 then
		self:SetCooldown("Puke",math.random(30,30))
		self:EmitSound("player/boomer/voice/vomit/male_boomer_vomit_0"..math.random(4)..".mp3")
		ParticleEffectAttach("boomer_vomit",PATTACH_POINT_FOLLOW,self,self:LookupAttachment("mouth"))		 
		self:PlaySequence("Vomit_Attack")
		self:Timer(1.8, function()
		self:CICO(function()
		self:PlaySequenceAndWait("ragdoll",60,self.FaceEnemy)
		end)
		end)
		self:PlaySequenceAndWait("Idle_Standing",1,self.FaceEnemy)
		end
	end}},
	[IN_DUCK] = {{coroutine = true,onkeydown = function(self)
		if self.Crouching == false then
		self:Timer(0.1,self.SetCollisionBounds, Vector(-15,-15,0), Vector(15, 15, 55))
		self.WalkAnimation = "Crouch_Walk_Upper_KNIFE"
		self.RunAnimation = "Crouch_Walk_Upper_KNIFE"
		self.IdleAnimation = "Crouch_Idle_Upper_KNIFE"
		self:Timer(0.5, function()
		self.Crouching = true
		end)
		end
		if self.Crouching == true then
		self:Timer(0.1,self.SetCollisionBounds, Vector(-15,-15,0), Vector(15, 15, 75))
		self.WalkAnimation = "Walk_Upper_Knife"
		self.RunAnimation = "Run_Upper_KNIFE"
		self.IdleAnimation = "Idle_Upper_KNIFE"
		self:Timer(0.5, function()
		self.Crouching = false
		end)
		end
	end}},
	[IN_JUMP] = {{coroutine = false,onkeydown = function(self)self:Jump(50)end}},
	[IN_ATTACK3] = {{coroutine = true,onkeydown = function(self)
		self:Suicide()
	end}},
}
function ENT:PossessionHalos() 
if !CLIENT then return end
halo.Add( ents.FindByClass( "player" ), Color( 0, 220, 0 ), 1, 1, 1, true, true )
halo.Add( ents.FindByClass( "npc_*" ), Color( 0, 220, 0 ), 1, 1, 1, true, true )
halo.Add( ents.FindByClass( "drg_l4d2_si_boomer*" ), Color( 0, 255, 255 ), 1, 1, 1, true, true )
halo.Add( ents.FindByClass( "drg_l4d2_si_boomette*" ), Color( 0, 255, 255 ), 1, 1, 1, true, true )
halo.Add( ents.FindByClass( "drg_l4d2_si_charger*" ), Color( 127, 159, 255 ), 1, 1, 1, true, true )
halo.Add( ents.FindByClass( "drg_l4d2_si_spitter*" ), Color( 220, 0, 255 ), 1, 1, 1, true, true )
halo.Add( ents.FindByClass( "drg_l4d2_si_jockey*" ), Color( 255, 191, 0 ), 1, 1, 1, true, true )
halo.Add( ents.FindByClass( "drg_l4d2_si_smoker*" ), Color( 0, 127, 31 ), 1, 1, 1, true, true )
halo.Add( ents.FindByClass( "drg_l4d2_si_witch*" ), Color( 255, 255, 255 ), 1, 1, 1, true, true )
halo.Add( ents.FindByClass( "drg_l4d2_si_hunter*" ), Color( 0, 161, 255 ), 1, 1, 1, true, true )
halo.Add( ents.FindByClass( "drg_l4d2_si_tank*" ), Color( 255, 0, 0 ), 1, 1, 1, true, true )
halo.Add( ents.FindByClass( "drg_l4d2_uci_jimmy*" ), Color( 255, 255, 255 ), 1, 1, 1, true, true )
end

function ENT:OnDealtDamage(ent, dmg)
	if string.find(ent:GetClass(), "drg_l4d2_ci") and self:IsPossessed() or string.find(ent:GetClass(), "drg_l4d_ci") and self:IsPossessed() or string.find(ent:GetClass(), "drg_l4d2_ci_") and self:IsPossessed() or string.find(ent:GetClass(), "drg_l4d2_uci_") and self:IsPossessed() then
	dmg:ScaleDamage(54)
	dmg:SetDamageType(DMG_BULLET)
	end
end
function ENT:PossessionRender()
	if !CLIENT then return end


	local tab = {
		[ "$pp_colour_addr" ] = 0.3,
		[ "$pp_colour_addg" ] = 0.21,
		[ "$pp_colour_addb" ] = 0,
		[ "$pp_colour_brightness" ] = -0.2,
		[ "$pp_colour_contrast" ] = 0.6,
		[ "$pp_colour_colour" ] = 2,
		[ "$pp_colour_mulr" ] = 1,
		[ "$pp_colour_mulg" ] = 1,
		[ "$pp_colour_mulb" ] = 0.25
		}

	DrawColorModify( tab )	
	
end
game.AddParticles("particles/boomer_fx.pcf")
game.AddParticles("particles/l4d2_blood_fx.pcf")

-- Climbing --
ENT.ClimbLedges = true
ENT.ClimbLedgesMaxHeight = 500
ENT.LedgeDetectionDistance = 60
ENT.ClimbProps = true
ENT.ClimbLadders = true
ENT.LaddersUpDistance = 60
ENT.ClimbSpeed = 100
ENT.ClimbUpAnimation = "Ladder_Ascend"
ENT.ClimbAnimRate = 1
ENT.ClimbOffset = Vector(0, 0, 70)

ENT.UseWalkframes = true

if SERVER then
function ENT:WhileClimbing(ladder, left)
	self:ResetSequence("Ladder_Ascend")
	self.JumpAnimation = "Ladder_Ascend"
end
function ENT:OnStopClimbing(ledge)
	self.JumpAnimation = "Jump"
	self:SetPos(ledge)
end

function ENT:OnSpawn()
	self:EmitSound("music/bacteria/boomerbacterias.wav")
		local glowlight = ents.Create("light_dynamic")
		glowlight:SetKeyValue("_light","127 0 255 255")
		glowlight:SetKeyValue("brightness","0.3")
		glowlight:SetKeyValue("distance","260")
		glowlight:SetKeyValue("style","0")
		glowlight:SetPos(self:GetPos()+self:GetUp()*50+self:GetForward()*20)
		glowlight:SetParent(self)
		glowlight:Spawn()
		glowlight:Activate()
		glowlight:Fire("TurnOn","",0)
		self.Light = glowlight
		self:DeleteOnRemove(glowlight)
	self:SetCollisionGroup(COLLISION_GROUP_INTERACTIVE_DEBRIS)
	self.Crouching = false
	self.Shoved = false
	self.Crouching = false
	self.OnIdleSounds = {
		"player/survivor/voice/coach/laughter01.wav","player/survivor/voice/coach/laughter02.wav",
		"player/survivor/voice/coach/laughter03.wav","player/survivor/voice/coach/laughter04.wav",
		"player/survivor/voice/coach/laughter05.wav","player/survivor/voice/coach/laughter06.wav",
		"player/survivor/voice/coach/laughter07.wav","player/survivor/voice/coach/laughter08.wav",
		"player/survivor/voice/coach/laughter09.wav","player/survivor/voice/coach/laughter10.wav",
		"player/survivor/voice/coach/laughter11.wav","player/survivor/voice/coach/laughter12.wav",
		"player/survivor/voice/coach/laughter13.wav","player/survivor/voice/coach/laughter14.wav",
		"player/survivor/voice/coach/laughter15.wav","player/survivor/voice/coach/laughter16.wav",
		"player/survivor/voice/coach/laughter17.wav","player/survivor/voice/coach/laughter18.wav",
		"player/survivor/voice/coach/laughter19.wav","player/survivor/voice/coach/laughter20.wav",
		"player/survivor/voice/coach/laughter21.wav","player/survivor/voice/coach/laughter22.wav",
		"player/survivor/voice/coach/laughter23.wav","music/bacteria/boomerbacterias.wav"
	}
	self.Axe = ents.Create("drg_l4d_bonemerge")
	self.Axe:SetModel("models/joe/seeker_fireaxe.mdl")
	self.Axe:Spawn()
	self.Axe:SetParent(self)
	self.Axe:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	self.IdleSoundDelay = 6
	self.Looked = false
	self.CalledOut = false
	self.CalledOutHear = false
end

function ENT:OnLandOnGround()
	if self:IsDown() or self:IsClimbing() then return end
	self:EmitSound("vj_l4d2/pz/fall/bodyfall_largecreature.mp3")
end

function ENT:CustomInitialize()
	self:SetDefaultRelationship(D_HT)
	
	self.WalkAnimation = "Walk_axe"
	self.RunAnimation = "Run_Axe"
	self.IdleAnimation = "Idle_Standing_axe"
	self.JumpAnimation = "Jump_axe_01"
	self:SetCooldown("Melee",math.random(0.5,0.5))
	self:SetCooldown("Pain",math.random(0.5,0.5))
	
	self.SOUND_EVTTABLE = {["custom_bodyfall_knee"] = {"codz_megapack/ww2/global/melee/zmb_slash_0", 9}}	
	self:Timer(0.1,self.SetCollisionBounds, Vector(-15,-15,0), Vector(15, 15, 75))
end

function ENT:HandleAnimEvent(a,b,c,d,e)
	if e == "attack" then
		self:Attack({
			damage = 15,
			type = DMG_SLASH,
			viewpunch = Angle(20, math.random(-10, 10), 0),
		}, 
		function(self, hit)
			if #hit > 0 then
				self:EmitSound("codz_megapack/ww2/global/melee/zmb_hit_0"..math.random(8)..".wav",100,math.random(95,105))
			end
		end)
	elseif e == "event_emit step" then
		if self:WaterLevel() > 0 and not self.Running then
		self:EmitSound("player/footsteps/survivor/walk/slosh"..math.random(4)..".wav")
		elseif self:WaterLevel() > 0 and self.Running then
		self:EmitSound("player/footsteps/survivor/run/slosh"..math.random(4)..".wav")
		else
		local tr = util.TraceLine({
			start=self:GetPos()+Vector(0,0,0),
			endpos=self:GetPos()+Vector(0,0,-40),
			filter=self
		})
		local mat = tr.MatType
		if tr.Hit then
			if mat == MAT_DIRT then
				self:EmitSound("player/footsteps/survivor/run/dirt"..math.random(4)..".wav")
			elseif mat == MAT_GRASS then
				self:EmitSound("player/footsteps/survivor/run/grass"..math.random(4)..".wav")
			elseif mat == MAT_SAND then
				self:EmitSound("player/footsteps/survivor/run/sand"..math.random(4)..".wav")
			elseif mat == MAT_CONCRETE then
				self:EmitSound("player/footsteps/survivor/run/concrete"..math.random(4)..".wav")
			elseif mat == MAT_TILE then
				self:EmitSound("player/footsteps/survivor/run/tile"..math.random(4)..".wav")
			elseif mat == MAT_WOOD then
				self:EmitSound("player/footsteps/survivor/run/wood"..math.random(4)..".wav")
			elseif mat == MAT_SLOSH then
				self:EmitSound("player/footsteps/survivor/run/slosh"..math.random(4)..".wav")
			elseif mat == MAT_GRATE then
				self:EmitSound("player/footsteps/survivor/run/metalgrate"..math.random(4)..".wav")
			elseif mat == MAT_VENT then
				self:EmitSound("player/footsteps/survivor/run/duct"..math.random(4)..".wav")
			elseif mat == MAT_METAL then
				self:EmitSound("player/footsteps/survivor/run/metal"..math.random(4)..".wav")
			end
		end
		end
	end
	
	local evt = string.Explode(" ", e, false)
	if evt[1] == "ps" then
		local snd = self.SOUND_EVTTABLE[evt[2]]
		self:EmitSound(snd[1]..math.random(snd[2])..".wav")
	end
end

function ENT:OnMeleeAttack(enemy)
	if self:GetCooldown("Melee") == 0 then
	self:SetCooldown("Melee",math.random(2,2))
	self:PlaySequence("axe_swing_layer_2")
	self:Timer(0.4, function()
		self:Attack({
			damage = 100,
			type = DMG_SLASH,
			viewpunch = Angle(20, math.random(-10, 10), 0),
		}, 
		function(self, hit)
			if #hit == 0 then self:EmitSound("weapons/axe/axe_swing_miss2.wav")return end 
			self:EmitSound("weapons/axe/axe_impact_flesh"..math.random(4)..".wav")
		end)
	end)
	end
end
function ENT:OnContact(ent)
	if string.find(ent:GetClass(),"prop") and not string.find(ent:GetClass(),"combine_ball") then
		if ent:GetModel() == "models/props_windows/hotel_window_glass002.mdl" or ent:GetModel() == "models/props_windows/hotel_window_glass001.mdl" then
			ent:Fire("break")
		end
	end
end

function ENT:OnIdle()self:AddPatrolPos(self:RandomPos(1500))end
function ENT:OnReachedPatrol(pos)self:Wait(math.random(3, 7))end 

function ENT:OnTraceAttack(dmg,dir,tr)
	dmg:ScaleDamage(0.3)
end
function ENT:OnTakeDamage(dmg,hg)
	dmg:ScaleDamage(0.3)
	if self.Flinching or self:IsDown() then return end
	if dmg:GetAttacker():IsPlayer() and self:GetCooldown("Pain") == 0 then
	self:SetCooldown("Pain",math.random(2,2))
	local pain = math.random(3)
	if pain==1 then
	self:EmitSound("player/survivor/voice/coach/friendlyfire0"..math.random(1,9)..".wav")
	elseif pain==2 then
	self:EmitSound("player/survivor/voice/coach/friendlyfire"..math.random(10,29)..".wav")
	elseif pain==3 then
		local guy = dmg:GetAttacker()
		if guy:GetModel() == "models/l4dfixedpm/nick.mdl" then
		self:EmitSound("player/survivor/voice/coach/friendlyfirec1gambler0"..math.random(4)..".wav")
		end
		if guy:GetModel() == "models/l4dfixedpm/ellis.mdl" then
		self:EmitSound("player/survivor/voice/coach/friendlyfirec1mechanic0"..math.random(4)..".wav")
		end
	end
	end
	if self:IsOnFire() && IsValid(DamageInflictor) && IsValid(DamageAttacker) && DamageInflictor:GetClass() == "entityflame" && DamageAttacker:GetClass() == "entityflame" then
	self:Extinguish()
	end
	if (dmg:IsDamageType(DMG_BURN) or dmg:IsDamageType(DMG_SLOWBURN) or (self:IsOnFire() && IsValid(DamageInflictor) && IsValid(DamageAttacker) && DamageInflictor:GetClass() == "entityflame" && DamageAttacker:GetClass() == "entityflame")) then
	self:Extinguish()
	end
	if dmg:IsDamageType(DMG_SONIC) then 
		dmg:ScaleDamage(0)
		dmg:SetDamage(0)
		self.Flinching = true
		local fwd = self:GetPos()+self:GetForward()*1
		local bck = self:GetPos()-self:GetForward()*1
		local lft = self:GetPos()-self:GetRight()*1
		local rit = self:GetPos()+self:GetRight()*1
		local pos = dmg:GetDamagePosition()
		if fwd:DistToSqr(pos) < bck:DistToSqr(pos) 
		and fwd:DistToSqr(pos) < lft:DistToSqr(pos) 
		and fwd:DistToSqr(pos) < rit:DistToSqr(pos) then
			self.Shoved = true
			self:CICO(function()
			self:PlaySequenceAndMove("Shoved_Backward_Melee")
			self.Shoved = false
			end)
		elseif bck:DistToSqr(pos) < fwd:DistToSqr(pos) 
		and bck:DistToSqr(pos) < lft:DistToSqr(pos) 
		and bck:DistToSqr(pos) < rit:DistToSqr(pos) then
			self.Shoved = true
			self:CICO(function()
			self:PlaySequenceAndMove("Shoved_Forward_Melee")
			self.Shoved = false
			end)
		elseif lft:DistToSqr(pos) < fwd:DistToSqr(pos) 
		and lft:DistToSqr(pos) < bck:DistToSqr(pos) 
		and lft:DistToSqr(pos) < rit:DistToSqr(pos) then
			self.Shoved = true
			self:CICO(function()
			self:PlaySequenceAndMove("Shoved_Rightward_Melee")
			self.Shoved = false
			end)
		elseif rit:DistToSqr(pos) < fwd:DistToSqr(pos) 
		and rit:DistToSqr(pos) < lft:DistToSqr(pos) 
		and rit:DistToSqr(pos) < bck:DistToSqr(pos) then
			self.Shoved = true
			self:CICO(function()
			self:PlaySequenceAndMove("Shoved_Leftward_Melee")
			self.Shoved = false
			end)
		end
		self.Flinching = false
	end
	if dmg:IsDamageType(DMG_BLAST) then 
		self.Flinching = true
		self:CICO(function()
		local fwd = self:GetPos()+self:GetForward()*1
		local bck = self:GetPos()-self:GetForward()*1
		local lft = self:GetPos()-self:GetRight()*1
		local rit = self:GetPos()+self:GetRight()*1
		local pos = dmg:GetDamagePosition()
		if fwd:DistToSqr(pos) < bck:DistToSqr(pos) 
		and fwd:DistToSqr(pos) < lft:DistToSqr(pos) 
		and fwd:DistToSqr(pos) < rit:DistToSqr(pos) then
			self.Shoved = true
			self:CICO(function()
			self:PlaySequenceAndMove("Shoved_Backward_Melee")
			self.Shoved = false
			end)
		elseif bck:DistToSqr(pos) < fwd:DistToSqr(pos) 
		and bck:DistToSqr(pos) < lft:DistToSqr(pos) 
		and bck:DistToSqr(pos) < rit:DistToSqr(pos) then
			self.Shoved = true
			self:CICO(function()
			self:PlaySequenceAndMove("Shoved_Forward_Melee")
			self.Shoved = false
			end)
		elseif lft:DistToSqr(pos) < fwd:DistToSqr(pos) 
		and lft:DistToSqr(pos) < bck:DistToSqr(pos) 
		and lft:DistToSqr(pos) < rit:DistToSqr(pos) then
			self.Shoved = true
			self:CICO(function()
			self:PlaySequenceAndMove("Shoved_Rightward_Melee")
			self.Shoved = false
			end)
		elseif rit:DistToSqr(pos) < fwd:DistToSqr(pos) 
		and rit:DistToSqr(pos) < lft:DistToSqr(pos) 
		and rit:DistToSqr(pos) < bck:DistToSqr(pos) then
			self.Shoved = true
			self:CICO(function()
			self:PlaySequenceAndMove("Shoved_Leftward_Melee")
			self.Shoved = false
			end)
		end
		self.Flinching = false
		end)
	end
end
function ENT:OnRangeAttack()
end
function ENT:OnFatalDamage()return true end
function ENT:OnDowned(dmg)
		Seekerdie = "music/undeath/leftfordeath.wav"
			local locateplayers = player.GetAll()
			for i = 1, table.getn(locateplayers) do
			locateplayers[i]:ConCommand("play " .. Seekerdie .. "\n")
			end
		local guy = dmg:GetAttacker()
		if guy:GetModel() == "models/l4dfixedpm/nick.mdl" then
		local callk = math.random(2)
			if callk==1 then
			guy:EmitSound("player/survivor/voice/gambler/survivormourncoach0"..math.random(3)..".wav")
			elseif callk==2 then
			guy:EmitSound("player/survivor/voice/gambler/survivormourncoachc10"..math.random(3)..".wav")
			end
		end
		if guy:GetModel() == "models/l4dfixedpm/ellis.mdl" then
		local callk = math.random(2)
			if callk==1 then
			guy:EmitSound("player/survivor/voice/mechanic/survivormourncoachc101.wav")
			elseif callk==2 then
			guy:EmitSound("player/survivor/voice/mechanic/survivormourncoach0"..math.random(5)..".wav")
			end
		end
	local col = self:GetCollisionGroup()
	self.CanAttack = false
	self.Axe:Remove()
	self.OnIdleSounds = {
		""
	}
	local axe = ents.Create("prop_physics")
	axe:SetModel("models/joe/seeker_fireaxe.mdl")
	axe:SetPos(self:GetPos()+self:GetUp()*57+self:GetForward()*20+self:GetRight())
	axe:SetAngles(self:GetAngles()  + Angle(0,50,50))
	axe:Spawn()
	axe:Activate()
	axe:SetCollisionGroup(COLLISION_GROUP_WEAPON)
	self:EmitSound("player/survivor/voice/coach/deathscream0"..math.random(9)..".wav")
	self:PlaySequenceAndMoveOverride("Die_Standing")
	self:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
	
	local duration = 30
	self:SetHealthRegen(math.ceil((self:GetMaxHealth()-self:Health())/duration))
	while self:Health() < self:GetMaxHealth() do
		self:YieldCoroutine(false)
	end
	self:SetCollisionGroup(col)
	self:EmitSound("weapons/defibrillator/defibrillator_use.wav")
	self:PlaySequenceAndMoveOverride("Defib_jolt")
	axe:Remove()
	self.Axe = ents.Create("drg_l4d_bonemerge")
	self.Axe:SetModel("models/joe/seeker_fireaxe.mdl")
	self.Axe:Spawn()
	self.Axe:SetParent(self)
	self.Axe:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	local def = math.random(3)
	if def==1 then
	self:EmitSound("player/survivor/voice/coach/defibrillator09.wav")
	elseif def==2 then
	self:EmitSound("player/survivor/voice/coach/defibrillator"..math.random(10,14)..".wav")
	elseif def==3 then
	self:EmitSound("player/survivor/voice/coach/defibrillator"..math.random(16,19)..".wav")
	end
	self:PlaySequenceAndMoveOverride("Defib_Revive")
	self.OnIdleSounds = {
		"player/survivor/voice/coach/laughter01.wav","player/survivor/voice/coach/laughter02.wav",
		"player/survivor/voice/coach/laughter03.wav","player/survivor/voice/coach/laughter04.wav",
		"player/survivor/voice/coach/laughter05.wav","player/survivor/voice/coach/laughter06.wav",
		"player/survivor/voice/coach/laughter07.wav","player/survivor/voice/coach/laughter08.wav",
		"player/survivor/voice/coach/laughter09.wav","player/survivor/voice/coach/laughter10.wav",
		"player/survivor/voice/coach/laughter11.wav","player/survivor/voice/coach/laughter12.wav",
		"player/survivor/voice/coach/laughter13.wav","player/survivor/voice/coach/laughter14.wav",
		"player/survivor/voice/coach/laughter15.wav","player/survivor/voice/coach/laughter16.wav",
		"player/survivor/voice/coach/laughter17.wav","player/survivor/voice/coach/laughter18.wav",
		"player/survivor/voice/coach/laughter19.wav","player/survivor/voice/coach/laughter20.wav",
		"player/survivor/voice/coach/laughter21.wav","player/survivor/voice/coach/laughter22.wav",
		"player/survivor/voice/coach/laughter23.wav","music/bacteria/boomerbacterias.wav"
	}
	self:SetHealthRegen(0)
	self.CanAttack = true
end
function ENT:OnDeath(dmg)
	self:SetHealth(1)
	self:OnDowned(dmg)
end
function ENT:OnRagdoll(dmg)
end

function ENT:UnCrouchAnim()
	if self.Crouching == true then
	self:Timer(0.1,self.SetCollisionBounds, Vector(-15,-15,0), Vector(15, 15, 75))
	self.WalkAnimation = "Walk_axe"
	self.RunAnimation = "Run_Axe"
	self.IdleAnimation = "Idle_Standing_axe"
	self.Crouching = false
	end
end
function ENT:CrouchAnim()
	if self.Crouching == false then
	self:Timer(0.1,self.SetCollisionBounds, Vector(-13,-13,0), Vector(13, 13, 40))
	self.WalkAnimation = "CrouchWalk_axe"
	self.RunAnimation = "CrouchWalk_axe"
	self.IdleAnimation = "Idle_Crouching_axe"
	self.Crouching = true
	end
end
function ENT:CustomThink()
	if self:IsDown() then return end
	local nav = navmesh.GetNearestNavArea( self:GetPos(), true,60,false,false,TEAM_ANY)
	if IsValid(nav) then
	if nav:GetAttributes() == 1 then
	self:CrouchAnim()
	else
	self:UnCrouchAnim()
	end
	end
	if self:IsPossessed() and not self:IsClimbing() and self.Shoved == false then
	self:PossessionFaceForward()
	end
	for k,v in pairs(ents.FindByClass("tfa_l4d1_fire_1")) do
	if self:GetPos():Distance(v:GetPos()) < 150 and self:IsAlive() then
	self:Ignite(300)
	end
	end
	if self:IsDown() then return end
	if self:IsPossessed() then
		self:DirectPoseParametersAt(self:PossessorTrace().HitPos, "body_pitch", "body_yaw", self:EyePos())
	elseif self:HasEnemy() and self:IsInSight(self:GetEnemy()) then
		self:DirectPoseParametersAt(self:GetEnemy():GetPos(), "body_pitch", "body_yaw", self:EyePos())
	else self:DirectPoseParametersAt(nil, "body_pitch", "body_yaw", self:EyePos()) end
	if (self:CanBeSeen()) == true and self.Looked == false then
	self.Looked = true
	else
	self.Looked = false
	end
	self:RemoveAllDecals()
end
function ENT:CanBeSeen()
	local tb = {}
	for _,v in ipairs(player.GetAll()) do
		if GetConVarNumber("ai_ignoreplayers") == 1 then return false end
		if v:IsPlayer() && v:Visible(self) then
			if v.IsPossessing == false && self.CalledOut == false && v:Alive() && v:IsFlagSet(FL_NOTARGET) != true && self:Disposition(v) != D_LI && self:GetHullRangeSquaredTo(v) < 800^2 && v:Visible(self) && (v:GetForward():Dot(((self:GetPos() +self:OBBCenter() +self:GetForward() *-30) -v:GetPos() +v:OBBCenter()):GetNormalized()) > math.cos(math.rad(70))) then
				if !table.HasValue(tb) then
					table.insert(tb,v)
					if v:GetModel() == "models/l4dfixedpm/nick.mdl" then
					self.CalledOut = true
						local call = math.random(2)
						if call==1 then
						v:EmitSound("player/survivor/voice/gambler/namecoach"..math.random(10,12)..".wav")
						elseif call==2 then
						v:EmitSound("player/survivor/voice/gambler/namecoach0"..math.random(9)..".wav")
						end
					end
					if v:GetModel() == "models/l4dfixedpm/ellis.mdl" then
					self.CalledOut = true
						local call = math.random(2)
						if call==1 then
						v:EmitSound("player/survivor/voice/mechanic/namecoach0"..math.random(9)..".wav")
						elseif call==2 then
						v:EmitSound("player/survivor/voice/mechanic/namecoach"..math.random(10,15)..".wav")
						end
					end
				end
			else
				if table.HasValue(tb) && tb[v] != nil then
					tb[v] = nil
				end
			end
		end
	end
	for _,v in ipairs(tb) do
		if v == nil then
			return false
		end
		return true
	end
	return false
end
function ENT:OnUpdateAnimation()
	if self:IsDown() then return end
	if not self:IsOnGround() then return self.JumpAnimation, self.JumpAnimRate
	elseif self:IsRunning() then return self.RunAnimation, self.RunAnimRate
	elseif self:IsMoving() then return self.WalkAnimation, self.WalkAnimRate
	else return self.IdleAnimation, self.IdleAnimRate end
end

function ENT:CICO(callback)
	local oldThread = self.BehaveThread
	self.BehaveThread = coroutine.create(function()
		callback(self)
		self.BehaveThread = oldThread
	end)
end
function ENT:PlaySequenceAndMoveOverride(anim, override, options, callback)
	override = override or {overrider=false,overridable=true}
	if isbool(override) or isnumber(override) then 
		return self:PlaySequenceAndMoveOverride(anim,{overrider=false,overridable=true},options,callback)
	end
	
	if override.overrider then self.StopAnim = true end
	callback = callback or function()return end
    return self:PlaySequenceAndMove(anim, options, function(self, cycle)
        if self.StopAnim and override.overridable then
			self.StopAnim = false
			return true
		else
			self.StopAnim = false
		end
        return callback(self, cycle)
    end)
end
end

-- DO NOT TOUCH --
AddCSLuaFile()
DrGBase.AddNextbot(ENT)
