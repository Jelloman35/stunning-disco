if not DrGBase then return end -- return if DrGBase isn't installed
ENT.Base = "drgbase_nextbot" -- DO NOT TOUCH (obviously)

-- Misc --
ENT.PrintName = "Hoovydundy"
ENT.Category = "Slender Fortress"
ENT.Models = {"models/painkiller_76/sf2/hoovydundy/hoovy.mdl"}
ENT.Skins = {0}
ENT.ModelScale = 1
ENT.CollisionBounds = Vector(10, 10, 72)
ENT.BloodColor = BLOOD_COLOR_RED
ENT.RagdollOnDeath = true

-- Stats --
ENT.SpawnHealth = 90000
ENT.HealthRegen = 5
ENT.MinPhysDamage = 10
ENT.MinFallDamage = 10

-- Sounds --
ENT.OnSpawnSounds = { "hoovy/death1.wav" }
ENT.OnIdleSounds = { "hoovy/bmg.wav" }
ENT.IdleSoundDelay = 2
ENT.ClientIdleSounds = false
ENT.OnDamageSounds = {}
ENT.DamageSoundDelay = 0.25
ENT.OnDeathSounds = {}
ENT.OnDownedSounds = {}
ENT.Footsteps = {}

-- AI --
ENT.Omniscient = false
ENT.SpotDuration = 30
ENT.RangeAttackRange = 0
ENT.MeleeAttackRange = 50
ENT.ReachEnemyRange = 50
ENT.AvoidEnemyRange = 0

-- Relationships --
ENT.Factions = {"FACTION_SLENDER"}
ENT.Frightening = true
ENT.AllyDamageTolerance = 0.33
ENT.AfraidDamageTolerance = 0.33
ENT.NeutralDamageTolerance = 0.33

-- Locomotion --
ENT.Acceleration = 2000
ENT.Deceleration = 1
ENT.JumpHeight = 50
ENT.StepHeight = 20
ENT.MaxYawRate = 250
ENT.DeathDropHeight = 200

-- Animations --
ENT.WalkAnimation = "Run1"
ENT.WalkAnimRate = 1
ENT.RunAnimation = "Run2"
ENT.RunAnimRate = 1
ENT.IdleAnimation = "idle"
ENT.IdleAnimRate = 1
ENT.JumpAnimation = "Run2"
ENT.JumpAnimRate = 1

-- Movements --
ENT.UseWalkframes = false
ENT.WalkSpeed = 300
ENT.RunSpeed = 3000

-- Climbing --
ENT.ClimbLedges = false
ENT.ClimbLedgesMaxHeight = math.huge
ENT.ClimbLedgesMinHeight = 0
ENT.LedgeDetectionDistance = 20
ENT.ClimbProps = false
ENT.ClimbLadders = false
ENT.ClimbLaddersUp = true
ENT.LaddersUpDistance = 20
ENT.ClimbLaddersUpMaxHeight = math.huge
ENT.ClimbLaddersUpMinHeight = 0
ENT.ClimbLaddersDown = false
ENT.LaddersDownDistance = 20
ENT.ClimbLaddersDownMaxHeight = math.huge
ENT.ClimbLaddersDownMinHeight = 0
ENT.ClimbSpeed = 60
ENT.ClimbUpAnimation = ACT_CLIMB_UP
ENT.ClimbDownAnimation = ACT_CLIMB_DOWN
ENT.ClimbAnimRate = 1
ENT.ClimbOffset = Vector(0, 0, 0)

-- Detection --
ENT.EyeBone = "bip_head"
ENT.EyeOffset = Vector(0, 0, 0)
ENT.EyeAngle = Angle(0, 0, 0)
ENT.SightFOV = 150
ENT.SightRange = 15000
ENT.MinLuminosity = 0
ENT.MaxLuminosity = 1
ENT.HearingCoefficient = 1

-- Weapons --
ENT.UseWeapons = false
ENT.Weapons = {}
ENT.WeaponAccuracy = 1
ENT.WeaponAttachment = "Anim_Attachment_RH"
ENT.DropWeaponOnDeath = false
ENT.AcceptPlayerWeapons = true

-- Possession --
ENT.PossessionEnabled = true
ENT.PossessionMovement = POSSESSION_MOVE_1DIR
ENT.PossessionViews = {
	{
		offset = Vector(-10, 15, 35),
		distance = 60
	},
	{
		offset = Vector(7.5, 0, 0),
		distance = 0,
		eyepos = true
	}
}
ENT.PossessionBinds = {
	[IN_ATTACK] = {{
		coroutine = true,
		onkeydown = function(self)
			self:AttackFunction()
		end
	}}
}

if SERVER then

function ENT:CustomInitialize()
	self:SetDefaultRelationship(D_HT)
	self:SequenceEvent("throw_fire",25/87,self.AttackFunction)
end

function ENT:CustomThink()
	for k,ball in pairs(ents.FindInSphere(self:LocalToWorld(Vector(0,0,75)), 50)) do
		if IsValid(ball) and ball:GetClass() == "prop_door_rotating" then
			if ball:GetClass() == "prop_door_rotating" then self:DoorCode(ball) end
			if ball:GetClass() == "func_door_rotating" then ball:Fire("open") end
			if ball:GetClass() == "func_door" then ball:Fire("open") end
		end
	end
end

  -- These hooks are called when the nextbot has an enemy (inside the coroutine)
function ENT:OnMeleeAttack(enemy)
	self:PlaySequence("throw_fire")
end

function ENT:OnSpawn()
	self:EmitSound("hoovy/death1.wav", 511, 100)
	self:DynamicLight()
end

function ENT:AttackFunction()
	self:Attack({
		damage = 90000,
		viewpunch = Angle(45, 0, 0),
		type = DMG_BLAST,range=85,angle=125,
	}, function(self, hit)
		if #hit == 0 then return end 
		if self:IsPossessed() then
			if IsValid(self) and IsValid(self:GetClosestEnemy()) then
				if self:GetClosestEnemy().IsDrGNextbot then
					self:GetClosestEnemy():SetVelocity( self:GetForward() * 120 +self:GetUp() * 50)
					self:GetClosestEnemy():Jump(50)
				else
					self:GetClosestEnemy():SetVelocity( self:GetForward() * 120 +self:GetUp() * 50)
				end
			end
		else
			if IsValid(self) and IsValid(self:GetEnemy()) then
				if self:GetEnemy().IsDrGNextbot then
					self:GetEnemy():SetVelocity( self:GetForward() * 120 +self:GetUp() * 50)
					self:GetEnemy():Jump(50)
				else
					self:GetEnemy():SetVelocity( self:GetForward() * 120 +self:GetUp() * 50)
				end
			end
		end
	end)
end

function ENT:DynamicLight(color, radius, brightness,style,att)
	if color == nil then color = Color(255, 0, 0) end
	if not isnumber(radius) then radius = 1000 end
	radius = math.Clamp(radius, 3, math.huge)
	if not isnumber(brightness) then brightness = 1 end
	brightness = math.Clamp(brightness, 3, math.huge)
	local light = ents.Create("light_dynamic")
	light:SetKeyValue("brightness", (brightness))
	light:SetKeyValue("distance", (radius))
	light:Fire("Color", "255 0 0")
	light:SetParent(self)
	light:Spawn()
	light:Activate()
	light:Fire("LightOn")
	light:Fire("setparentattachment","back_lower")
	self:DeleteOnRemove(light)
	return light
end

function ENT:DoorCode(door)
	if self:GetCooldown("MRXDoor") == 0 then
		self:SetCooldown("MRXDoor", 6)
		local doorseq,doordur = self:LookupSequence("9200")
		local doorseq2,doordur2 = self:LookupSequence("9201")
		if IsValid(door) and door:GetClass() == "prop_door_rotating" then
			self.CanOpenDoor = false
			self.CanAttack = false
			self:SetNotSolid(true)
			door:SetNotSolid(true)
			-- find ourselves to know which side of the door we're on
			local fwd = door:GetPos()+door:GetForward()*5
			local bck = door:GetPos()-door:GetForward()*5
			local pos = self:GetPos()
			local fuck_double_doors1 = door:GetKeyValues()
			local fuck_double_doors2 = nil
			if isstring(fuck_double_doors1.slavename) and fuck_double_doors1.slavename != "" then
				fuck_double_doors2 = ents.FindByName(fuck_double_doors1.slavename)[1]
			end

			if fwd:DistToSqr(pos) < bck:DistToSqr(pos) then -- entered from forward
				self:SetNotSolid(true)
				door:SetNotSolid(true)
				if isentity(fuck_double_doors2) then
					self:SetPos(door:GetPos()+(door:GetForward()*50)+(door:GetRight()*-50)+(door:GetUp()*-52))
				else
					self:SetPos(door:GetPos()+(door:GetForward()*80)+(door:GetRight()*-32)+(door:GetUp()*-52))
				end
				local ang = door:GetAngles()
				ang:RotateAroundAxis(Vector(0,0,1),180)
				self:SetAngles(ang)
			elseif bck:DistToSqr(pos) < fwd:DistToSqr(pos) then -- entered from backward
				self:SetNotSolid(true)
				door:SetNotSolid(true)
				if isentity(fuck_double_doors2) then
					self:SetPos(door:GetPos()+(door:GetForward()*-50)+(door:GetRight()*-50)+(door:GetUp()*-52))
				else
					self:SetPos(door:GetPos()+(door:GetForward()*-80)+(door:GetRight()*-12)+(door:GetUp()*-52))
				end
				local a = (door:GetAngles())
				a:Normalize()
				self:SetAngles(a)
			end
			-- find ourselves to know which side of the door we're on
			if (fwd:DistToSqr(pos) < bck:DistToSqr(pos)) or (bck:DistToSqr(pos) < fwd:DistToSqr(pos)) then

				self:SetNotSolid(true)
				door:SetNotSolid(true)
				door:Fire("setspeed",500)

				if isentity(fuck_double_doors2) then
					fuck_double_doors2:SetNotSolid(true)
					fuck_double_doors2:Fire("setspeed",500)

					self:Timer(7/30,function()
						self:EmitSound("doors/vent_open3.wav",511,math.random(50,80))
						door:Fire("openawayfrom",self:GetName())
						fuck_double_doors2:Fire("openawayfrom",self:GetName())
					end)
					self:Timer(doordur2,function()
						door:Fire("setspeed",100)
						door:Fire("close")
						fuck_double_doors2:Fire("setspeed",100)
						fuck_double_doors2:Fire("close")
						self:Timer(1,function()
							door:SetNotSolid(false)
							fuck_double_doors2:SetNotSolid(false)
							self.CanOpenDoor = true
							self.CanAttack = true
							self.CanFlinch = false
							self:SetNotSolid(false)
						end)
					end)
					self:PlaySequence("9201",{rate=1, gravity=true, collisions=false})
				else
					self:Timer(0.5,function()
						if !IsValid(self) then return end
						self:EmitSound("doors/vent_open3.wav",511,math.random(50,80))
						door:Fire("openawayfrom",self:GetName())
					end)
					self:Timer(doordur,function()
						if !IsValid(self) then return end
						door:Fire("setspeed",100)
						door:Fire("close")
						self:Timer(0.2,function()
							door:SetNotSolid(false)
							if !IsValid(self) then return end
							self.CanOpenDoor = true
							self.CanAttack = true
							self.CanFlinch = false
							self:SetNotSolid(false)
						end)
					end)
					self:PlaySequence("9200",{rate=1, gravity=true, collisions=false})
				end
			else
				self:Timer(1,function()
					door:SetNotSolid(false)
					self:Timer(1,function()
						if !IsValid(self) then return end
						self.CanOpenDoor = true
					end)
					if !IsValid(self) then return end
					self.CanAttack = true
					self.CanFlinch = false
					self:SetNotSolid(false)
				end)
			end
		end
	end
end

function ENT:OnDeath(dmg, hitgroup)
	if self.ThemeSongLoop then 
		self.ThemeSongLoop:Stop()
	end
	self:EmitSound("hoovy/enraged.wav", 511, 100)
end

function ENT:OnOtherKilled(ent, dmg)
	local attacker = dmg:GetAttacker()
	if IsValid(attacker) and attacker == self then
		self:EmitSound("hoovy/death2.wav", 511, 100)
	end
end
end

function ENT:OnNewEnemy(enemy)
	self:EmitSound("hoovy/enraged.wav")
end
function ENT:OnPhysDamage(ent, data)
	if string.find(data.HitEntity:GetClass(), "tf_") then return end
	return (data.TheirOldVelocity:Length()*data.HitObject:GetMass())/1000
end
function ENT:_HandleCollide(data)
	if string.find(data.HitEntity:GetClass(), "tf_") then return end
	local ent = data.HitEntity
	if not IsValid(ent) then return end
	local class = ent:GetClass()
	local phys = data.HitObject
	if class == "prop_combine_ball" then
	if self:IsFlagSet(FL_DISSOLVING) then return end
	if not self:OnCombineBall(ent) then
	if not self:IsDead() then
		local dmg = DamageInfo()
		local owner = ent:GetOwner()
		dmg:SetAttacker(IsValid(owner) and owner or ent)
		dmg:SetInflictor(ent)
		dmg:SetDamage(1000)
		dmg:SetDamageType(DMG_DISSOLVE)
		dmg:SetDamageForce(ent:GetVelocity())
		self:TakeDamageInfo(dmg)
	else self:DrG_Dissolve() end
	ent:EmitSound("NPC_CombineBall.KillImpact")
	end
	elseif not ent:IsPlayerHolding() then
	local damage = math.floor(self:OnPhysDamage(ent, data))
	if damage > math.max(0, self.MinPhysDamage) then
		local dmg = DamageInfo()
		if ent:IsVehicle() and IsValid(ent:GetDriver()) then
		dmg:SetAttacker(ent:GetDriver())
		elseif IsValid(ent:GetPhysicsAttacker()) then
		dmg:SetAttacker(ent:GetPhysicsAttacker())
		else dmg:SetAttacker(ent) end
		dmg:SetInflictor(ent)
		dmg:SetDamage(damage)
		if ent:IsVehicle() then
		dmg:SetDamageType(DMG_VEHICLE)
		else dmg:SetDamageType(DMG_CRUSH) end
		dmg:SetDamageForce(phys:GetVelocity())
		self:TakeDamageInfo(dmg)
		end
	end
end

function ENT:OnMeleeAttack(enemy)
	if enemy:IsPlayer() then
		self:PlayerAttackFunction()
	else
		self:AttackFunction()
	end
end

function ENT:PlayerAttackFunction()
	self:Attack({
		damage = 300,
		viewpunch = Angle(45, 0, 0),
		type = DMG_CRUSH,range=85,angle=125,
	}, function(self, hit)
		if #hit == 0 then return end 
		if self:IsPossessed() then
			if IsValid(self) and IsValid(self:GetClosestEnemy()) then
				if self:GetClosestEnemy().IsDrGNextbot then
					self:GetClosestEnemy():SetVelocity( self:GetForward() * 120 +self:GetUp() * 50)
					self:GetClosestEnemy():Jump(50)
				else
					self:GetClosestEnemy():SetVelocity( self:GetForward() * 120 +self:GetUp() * 50)
				end
			end
		else
			if IsValid(self) and IsValid(self:GetEnemy()) then
				if self:GetEnemy().IsDrGNextbot then
					self:GetEnemy():SetVelocity( self:GetForward() * 120 +self:GetUp() * 50)
					self:GetEnemy():Jump(50)
				else
					self:GetEnemy():SetVelocity( self:GetForward() * 120 +self:GetUp() * 50)
				end
			end
		end
	end)
end

-- DO NOT TOUCH --
AddCSLuaFile()
DrGBase.AddNextbot(ENT)