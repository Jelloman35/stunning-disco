if not DrGBase then return end -- return if DrGBase isn't installed
ENT.Base = "drgbase_nextbot" -- DO NOT TOUCH (obviously)

-- Misc --
ENT.PrintName = "Bearded Expense"
ENT.Category = "Slender Fortress"
ENT.Models = {"models/player/heavy.mdl"}
ENT.BloodColor = BLOOD_COLOR_RED
ENT.CollisionBounds = Vector(14, 14, 83)
ENT.RagdollOnDeath = true
ENT.OnIdleSounds={"hoovy/hoovy_alert_01.wav","hoovy/hoovy_alert_02.wav","hoovy/hoovy_alert_03.wav"}
ENT.IdleSoundDelay = 3
ENT.SpotDuration = 5

-- Stats --
ENT.SpawnHealth = 90000
ENT.ShoveResistance = true
ENT.DamageMultipliers = {}

-- AI --
ENT.MeleeAttackRange = 50
ENT.ReachEnemyRange = 50
ENT.AvoidEnemyRange = 0

-- Relationships --
ENT.Factions = {"FACTION_SLENDER"}
ENT.Frightening = true

-- Movements/animations --
ENT.UseWalkframes = false
ENT.WalkAnimation = "ref"
ENT.RunAnimation = "ref"
ENT.IdleAnimation = "ref"
ENT.JumpAnimation = "ref"
ENT.RunSpeed = 700
ENT.WalkSpeed = 700

-- Climbing --
ENT.ClimbLedges = false
ENT.ClimbProps = false
ENT.ClimbLadders = false

-- Detection --
ENT.EyeBone = "head"
ENT.EyeOffset = Vector(10, 0, 1)
ENT.EyeAngle = Angle(0, 0, 0)

-- Possession --
ENT.PossessionEnabled = false
ENT.PossessionMovement = POSSESSION_MOVE_1DIR
ENT.PossessionViews = {
	{
		offset = Vector(0, 15, 15),
		distance = 70
	},
	{
		offset = Vector(7.5, 0, 0),
		distance = 0,
		eyepos = true
	}
}
ENT.PossessionBinds = {
	[IN_ATTACK] = {{
		coroutine = true,
		onkeydown = function(self)
			if self:GetCooldown("NemesisRangeAttack") == 0 then
			self:SetCooldown("NemesisRangeAttack",math.random(1,1))
			self:PlaySequence("AttackStand_Melee_allclass")
			self:Timer(0.3, function()
			self:AttackFunction(65,self.DamageType)
			end)
			end
		end
	}},
	[IN_JUMP] = {{coroutine = true,onkeydown = function(self)self:Jump()end}}
}

if SERVER then
function ENT:AttackFunction(dmg,dmgtype,sndhit)
	self:Attack({
		damage = dmg,
		viewpunch = Angle(40, 0, 0),
		type = dmgtype,
		range=self.MeleeAttackRange-math.random(10),
		angle=135,
	}, function(self, hit)
		if self:GetSequenceName(self:GetSequence())=="att4" then return end
		if #hit == 0 then self:EmitSound("hoovy/hoovy_scare.wav")return end 
		self:EmitSound("npc/witch/hit/hit_slimesplat"..math.random(3,5)..".wav")
	end)
end

function ENT:CustomInitialize()
	self:SetDefaultRelationship(D_HT, 1)
	self:SetAttack("att1_l", true)
	self.H = ents.Create("obj_re7_bonemerge")
	self.H:SetModel("models/player/items/heavy/hounddog.mdl")
	self.H:Spawn()
	self.H:SetParent(self)
	self.H:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	self.H.ProxyentPaintColor = ents.Create("proxyent_tf2itempaint")

	self.H.ProxyentPaintColor:SetTargetEnt(self.H)
	self.H.ProxyentPaintColor:SetPaintVector(Vector(20/255, 20/255, 20/255))

	self.H.ProxyentPaintColor:Spawn()
	self.H.ProxyentPaintColor:Activate()
	self.D = ents.Create("obj_re7_bonemerge")
	self.D:SetModel("models/workshop/player/items/heavy/cc_summer2015_el_duderino/cc_summer2015_el_duderino.mdl")
	self.D:Spawn()
	self.D:SetParent(self)
	self.D:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	self.D.ProxyentPaintColor = ents.Create("proxyent_tf2itempaint")

	self.D.ProxyentPaintColor:SetTargetEnt(self.D)
	self.D.ProxyentPaintColor:SetPaintVector(Vector(20/255, 20/255, 20/255))

	self.D.ProxyentPaintColor:Spawn()
	self.D.ProxyentPaintColor:Activate()
	ParticleEffectAttach("superrare_purpleenergy",PATTACH_POINT_FOLLOW,self,1)
	self.E = ents.Create("obj_re7_bonemerge")
	self.E:SetModel("models/workshop/player/items/heavy/sbox2014_heavy_gunshow/sbox2014_heavy_gunshow.mdl")
	self.E:Spawn()
	self.E:SetParent(self)
	self.E:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
end
function ENT:HandleAnimEvent(a,b,c,d,e)
end

function ENT:OnLandOnGround()
	if self:IsDead() then return end
	self:CallInCoroutineOverride(function(self, delay)
		self:PlaySequence("ref")
	end)
end

function ENT:OnSpawn()
	self:EmitSound("hoovy/chickenisalive.ogg")
	ParticleEffect("xms_icicle_impact_dryice",self:GetPos(),Angle(0,0,0),nill)
	ParticleEffect("xms_icicle_impact_dryice",self:GetPos(),Angle(0,0,0),nill)
	ParticleEffect("xms_icicle_impact_dryice",self:GetPos(),Angle(0,0,0),nill)
end
function ENT:OnIdle()
end

function ENT:OnMeleeAttack(enemy)
	self:Timer(0.6, function()
	self:AttackFunction(150,self.DamageType)
	end)
	self:PlaySequenceAndWait("layer_taunt_yeti_prop",6,self.FaceEnemy)
end
-- Damage --
function ENT:OnTraceAttack(dmg,dir,tr)
end
function ENT:OnPhysDamage(ent, data)
	if string.find(data.HitEntity:GetClass(), "tf_") then return end
	return (data.TheirOldVelocity:Length()*data.HitObject:GetMass())/1000
end
function ENT:_HandleCollide(data)
	if string.find(data.HitEntity:GetClass(), "tf_") then return end
	local ent = data.HitEntity
	if not IsValid(ent) then return end
	local class = ent:GetClass()
	local phys = data.HitObject
	if class == "prop_combine_ball" then
	if self:IsFlagSet(FL_DISSOLVING) then return end
	if not self:OnCombineBall(ent) then
	if not self:IsDead() then
		local dmg = DamageInfo()
		local owner = ent:GetOwner()
		dmg:SetAttacker(IsValid(owner) and owner or ent)
		dmg:SetInflictor(ent)
		dmg:SetDamage(1000)
		dmg:SetDamageType(DMG_DISSOLVE)
		dmg:SetDamageForce(ent:GetVelocity())
		self:TakeDamageInfo(dmg)
	else self:DrG_Dissolve() end
	ent:EmitSound("NPC_CombineBall.KillImpact")
	end
	elseif not ent:IsPlayerHolding() then
	local damage = math.floor(self:OnPhysDamage(ent, data))
	if damage > math.max(0, self.MinPhysDamage) then
		local dmg = DamageInfo()
		if ent:IsVehicle() and IsValid(ent:GetDriver()) then
		dmg:SetAttacker(ent:GetDriver())
		elseif IsValid(ent:GetPhysicsAttacker()) then
		dmg:SetAttacker(ent:GetPhysicsAttacker())
		else dmg:SetAttacker(ent) end
		dmg:SetInflictor(ent)
		dmg:SetDamage(damage)
		if ent:IsVehicle() then
		dmg:SetDamageType(DMG_VEHICLE)
		else dmg:SetDamageType(DMG_CRUSH) end
		dmg:SetDamageForce(phys:GetVelocity())
		self:TakeDamageInfo(dmg)
		end
	end
end
function ENT:OnNewEnemy(enemy)
	self:EmitSound("hoovy/hoovy_scare.wav",511)
end
function ENT:OnOtherKilled(ent, dmg)
	local attacker = dmg:GetAttacker()
	if IsValid(attacker) and attacker == self then
		BerKill = "hoovy/hoovy_kill.wav"
			local locateplayers = player.GetAll()
			for i = 1, table.getn(locateplayers) do
			locateplayers[i]:ConCommand("play " .. BerKill .. "\n")
			end
		self:StopSound("slender/duckmedic/chase_music.wav")
	end
end

function ENT:OnFatalDamage()return false end
function ENT:OnDeath(dmg)
	self:StopSound("slender/duckmedic/chase_music.wav")
end
function ENT:OnRagdoll()
end
function ENT:OnLost()
end
function ENT:OnRemove()
	ParticleEffect("xms_icicle_impact_dryice",self:GetPos(),Angle(0,0,0),nill)
	ParticleEffect("xms_icicle_impact_dryice",self:GetPos(),Angle(0,0,0),nill)
	ParticleEffect("xms_icicle_impact_dryice",self:GetPos(),Angle(0,0,0),nill)
end

function ENT:CustomThink()
	self:RemoveAllDecals()
end
function ENT:OnUpdateAnimation()
	if self:IsDead() then return end
	if !self:IsOnGround() then return self.JumpAnimation, 1
	elseif self:IsRunning() then return self.RunAnimation, self.RunAnimRate
	elseif self:IsMoving() then return self.WalkAnimation, self.WalkAnimRate
	else return self.IdleAnimation, self.IdleAnimRate end
end

function ENT:CallInCoroutineOverride(callback)
	local oldThread = self.BehaveThread
	self.BehaveThread = coroutine.create(function()
		callback(self)
		self.BehaveThread = oldThread
	end)
end
end

-- DO NOT TOUCH --
AddCSLuaFile()
DrGBase.AddNextbot(ENT)