
AddCSLuaFile();

DEFINE_BASECLASS("base_anim");

ENT.PrintName		= "Slender Page";
ENT.Author			= "Jonascone";
ENT.Information		= "Collectable Slender pages!\nSlender Man+Pages addon required!";
ENT.Category		= "Slender Fortress";

ENT.Editable			= false;
ENT.Spawnable			= true;
ENT.AdminOnly			= false;
ENT.RenderGroup 		= RENDERGROUP_TRANSLUCENT;

local activePages = {};

function ENT:SpawnFunction(ply, tr, ClassName)
    // If we're not looking at something, there're already 8 pages, or, we're looking at the ceiling or floor, don't spawn!
	if (table.Count(activePages) >= 8) then return NULL; end
    
	local SpawnPos = tr.HitPos + tr.HitNormal - Vector(0, 0, 2);
	local ent = ents.Create(ClassName);
	local i = 0;
    while (i < 8) do
        if (!activePages[i]) then
            activePages[i] = ent;
            ent:SetSkin(i);
            break;
        end
        i = i + 1;
    end
    ent:SetPos(SpawnPos);
    ent:SetAngles(tr.HitNormal:Angle() + Angle(-4, 4, 0));
	ent:Spawn();
    ent:GetPhysicsObject():EnableMotion(false);
	ent:Activate();
	return ent;	
end

function ENT:Initialize()
    if (CLIENT) then return; end
    self:SetModel(Model("models/slender/sheet.mdl"));
    self:PhysicsInit(SOLID_VPHYSICS);
    self:SetMoveType(MOVETYPE_VPHYSICS);
    self:SetSolid(SOLID_VPHYSICS); 
    local phys = self:GetPhysicsObject();
    if (phys:IsValid()) then
        phys:Wake();
    end	
end

function ENT:Draw()
    self:DrawModel();
end

function ENT:PrintPages(ply)    
    ply:PrintMessage(HUD_PRINTCENTER, "Collected " .. ply.numPages .. " of 8 pages");
end

function ENT:RemovePage()
    if (CLIENT) then return; end
    for k, v in pairs(activePages) do
        if (v == self) then
            activePages[k] = nil;
         end
    end
    self:Remove();
end

function ENT:OnRemove()
    if (CLIENT) then return; end
    self:RemovePage();
end
function ENT:Use(ply, caller)
    if (CLIENT or ply:GetEyeTraceNoCursor().Entity != self) then return; end // Only remove the page if the player is aiming at it.
    ply.numPages = ply.numPages and ply.numPages < 8 and ply.numPages + 1 or 1;
    self:PrintPages(ply);
    ply:EmitSound(Sound("ui/item_paper_pickup.wav"), 100.0, math.random(100, 100));
    self:RemovePage();
end

hook.Add("PreDrawHalos", "SlenderPageHalo", function()
    halo.Add(ents.FindByClass("slender_page"), Color(128, 128, 128), 1, 1, 1);
end);