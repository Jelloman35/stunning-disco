if not DrGBase then return end -- return if DrGBase isn't installed
ENT.Base = "drgbase_nextbot" -- DO NOT TOUCH (obviously)

-- Misc --
ENT.PrintName = "Michael Myers"
ENT.Category = "Slender Fortress"
ENT.Models = {"models/chillax_sf2/dbd/myers/myers.mdl"}
ENT.BloodColor = BLOOD_COLOR_RED
ENT.CollisionBounds = Vector(15.55555555555556, 15.55555555555556, 92.22222222222222)
ENT.RagdollOnDeath = true
ENT.OnIdleSounds={"slender/dbd/myers/myers_idle_01.wav","slender/dbd/myers/myers_idle_02.wav","slender/dbd/myers/myers_idle_03.wav","slender/dbd/myers/myers_idle_04.wav","slender/dbd/myers/myers_idle_05.wav"}
ENT.IdleSoundDelay = 4
ENT.SpotDuration = 5

-- Stats --
ENT.SpawnHealth = 90000
ENT.ShoveResistance = true
ENT.DamageMultipliers = {}

-- AI --
ENT.MeleeAttackRange = 50
ENT.ReachEnemyRange = 50
ENT.AvoidEnemyRange = 0

-- Relationships --
ENT.Factions = {"FACTION_SLENDER"}
ENT.Frightening = true

-- Movements/animations --
ENT.UseWalkframes = false
ENT.WalkAnimation = "walk_2"
ENT.RunAnimation = "run_2"
ENT.IdleAnimation = "idle_1"
ENT.JumpAnimation = "run_3"
ENT.RunSpeed = 300
ENT.WalkSpeed = 45

-- Climbing --
ENT.ClimbLedges = false
ENT.ClimbProps = false
ENT.ClimbLadders = false

-- Detection --
ENT.EyeBone = "head"
ENT.EyeOffset = Vector(10, 0, 1)
ENT.EyeAngle = Angle(0, 0, 0)

-- Possession --
ENT.PossessionEnabled = true
ENT.PossessionMovement = POSSESSION_MOVE_1DIR
ENT.PossessionViews = {
	{
		offset = Vector(0, 15, 15),
		distance = 70
	},
	{
		offset = Vector(7.5, 0, 0),
		distance = 0,
		eyepos = true
	}
}
ENT.PossessionBinds = {
	[IN_ATTACK] = {{
		coroutine = true,
		onkeydown = function(self)
			if self:GetCooldown("NemesisRangeAttack") == 0 then
			self:SetCooldown("NemesisRangeAttack",math.random(1,1))
			self:PlaySequence("AttackStand_Melee_allclass")
			self:Timer(0.3, function()
			self:AttackFunction(65,self.DamageType)
			end)
			end
		end
	}},
	[IN_JUMP] = {{coroutine = true,onkeydown = function(self)self:Jump()end}}
}

if SERVER then
function ENT:AttackFunction(dmg,dmgtype,sndhit)
	if self.Flinching == true then return end
	self:Attack({
		damage = dmg,
		viewpunch = Angle(40, 0, 0),
		type = dmgtype,
		range=self.MeleeAttackRange-math.random(10),
		angle=135,
	}, function(self, hit)
		if self:GetSequenceName(self:GetSequence())=="att4" then return end
		if #hit == 0 then self:EmitSound("slender/dbd/myers/attack_01.wav")return end 
		self:EmitSound("slender/dbd/myers/attack_hit_01.wav")
	end)
end

function ENT:CustomInitialize()
	self.Flinching = false
	self:SetDefaultRelationship(D_HT, 1)
	self:SetAttack("att1_l", true)
	self:SetCooldown("Flinch",math.random(3,3))
	self:SetModelScale(0.9)
	self.Flinching = false
end

function ENT:OnLandOnGround()
	if self:IsDead() then return end
	self:CallInCoroutineOverride(function(self, delay)
		self:PlaySequence("jumpland_MELEE_ALLCLASS")
	end)
end

function ENT:OnSpawn()
	ParticleEffect("xms_icicle_impact_dryice",self:GetPos(),Angle(0,0,0),nill)
	ParticleEffect("xms_icicle_impact_dryice",self:GetPos(),Angle(0,0,0),nill)
	ParticleEffect("xms_icicle_impact_dryice",self:GetPos(),Angle(0,0,0),nill)
end

function ENT:OnMeleeAttack(enemy)
	self:Timer(0.35, function()
	self:AttackFunction(50,self.DamageType)
	end)
	self:PlaySequenceAndMove("attack_1",1.5,self.FaceEnemy)
end
-- Damage --
function ENT:OnPhysDamage(ent, data)
	if string.find(data.HitEntity:GetClass(), "tf_") then return end
	return (data.TheirOldVelocity:Length()*data.HitObject:GetMass())/1000
end
function ENT:_HandleCollide(data)
	if string.find(data.HitEntity:GetClass(), "tf_") then return end
	local ent = data.HitEntity
	if not IsValid(ent) then return end
	local class = ent:GetClass()
	local phys = data.HitObject
	if class == "prop_combine_ball" then
	if self:IsFlagSet(FL_DISSOLVING) then return end
	if not self:OnCombineBall(ent) then
	if not self:IsDead() then
		local dmg = DamageInfo()
		local owner = ent:GetOwner()
		dmg:SetAttacker(IsValid(owner) and owner or ent)
		dmg:SetInflictor(ent)
		dmg:SetDamage(1000)
		dmg:SetDamageType(DMG_DISSOLVE)
		dmg:SetDamageForce(ent:GetVelocity())
		self:TakeDamageInfo(dmg)
	else self:DrG_Dissolve() end
	ent:EmitSound("NPC_CombineBall.KillImpact")
	end
	elseif not ent:IsPlayerHolding() then
	local damage = math.floor(self:OnPhysDamage(ent, data))
	if damage > math.max(0, self.MinPhysDamage) then
		local dmg = DamageInfo()
		if ent:IsVehicle() and IsValid(ent:GetDriver()) then
		dmg:SetAttacker(ent:GetDriver())
		elseif IsValid(ent:GetPhysicsAttacker()) then
		dmg:SetAttacker(ent:GetPhysicsAttacker())
		else dmg:SetAttacker(ent) end
		dmg:SetInflictor(ent)
		dmg:SetDamage(damage)
		if ent:IsVehicle() then
		dmg:SetDamageType(DMG_VEHICLE)
		else dmg:SetDamageType(DMG_CRUSH) end
		dmg:SetDamageForce(phys:GetVelocity())
		self:TakeDamageInfo(dmg)
		end
	end
end
function ENT:OnNewEnemy(enemy)
end
function ENT:OnOtherKilled(ent, dmg)
end

function ENT:OnFatalDamage()return false end
function ENT:OnDeath(dmg)
	self:StopSound("slender/duckmedic/chase_music.wav")
end
function ENT:OnRagdoll()
end
function ENT:OnLost()
end
function ENT:OnIdle()
	local d = math.random(1,2)
	if d==1 then
	self.IdleAnimation = "idle_1"
	elseif d==2 then
	self.IdleAnimation = "idle_2"
	end
	self:AddPatrolPos(self:RandomPos(1500))
end
function ENT:OnRemove()
	ParticleEffect("xms_icicle_impact_dryice",self:GetPos(),Angle(0,0,0),nill)
	ParticleEffect("xms_icicle_impact_dryice",self:GetPos(),Angle(0,0,0),nill)
	ParticleEffect("xms_icicle_impact_dryice",self:GetPos(),Angle(0,0,0),nill)
end

function ENT:CustomThink()
	if (self:CanBeSeen()) == true then
	self.RunSpeed = 250
	self.RunAnimation = "run"
	else
	self.RunSpeed = 430
	self.RunAnimation = "run_2"
	end
	self:RemoveAllDecals()
end
function ENT:OnUpdateAnimation()
	if self:IsDead() then return end
	if !self:IsOnGround() then return self.JumpAnimation, 1
	elseif self:IsRunning() then return self.RunAnimation, self.RunAnimRate
	elseif self:IsMoving() then return self.WalkAnimation, self.WalkAnimRate
	else return self.IdleAnimation, self.IdleAnimRate end
end
function ENT:CanBeSeen()
	local tb = {}
	for _,v in ipairs(player.GetAll()) do
		if GetConVarNumber("ai_ignoreplayers") == 1 then return false end
		if v:IsPlayer() && v:Visible(self) then
			if v.IsPossessing == false && v:Alive() && self:Disposition(v) != D_LI && v:IsFlagSet(FL_NOTARGET) != true && self:GetHullRangeSquaredTo(v) < 2000^2 && v:Visible(self) && (v:GetForward():Dot(((self:GetPos() +self:OBBCenter() +self:GetForward() *-30) -v:GetPos() +v:OBBCenter()):GetNormalized()) > math.cos(math.rad(70))) then
				if !table.HasValue(tb) then
					table.insert(tb,v)
					self.RunSpeed = 250
					self.RunAnimation = "run"
				end
			else
				if table.HasValue(tb) && tb[v] != nil then
					tb[v] = nil
				end
			end
		end
	end
	for _,v in ipairs(tb) do
		if v == nil then
			return false
		end
		return true
	end
	return false
end

function ENT:CallInCoroutineOverride(callback)
	local oldThread = self.BehaveThread
	self.BehaveThread = coroutine.create(function()
		callback(self)
		self.BehaveThread = oldThread
	end)
end
end

-- DO NOT TOUCH --
AddCSLuaFile()
DrGBase.AddNextbot(ENT)