if not DrGBase then return end -- return if DrGBase isn't installed
ENT.Base = "drgbase_nextbot" -- DO NOT TOUCH (obviously)

-- Misc --
ENT.PrintName = "Simply"
ENT.Category = "STUPENDOUS DISFEATURE"
ENT.Models = {"models/painkiller_76/sf2/white_bear/corruptedwoody4/new/corruptedwoody4_fix.mdl"}
ENT.BloodColor = BLOOD_COLOR_RED
ENT.CollisionBounds = Vector(11.66666666666667, 11.66666666666667, 69.16666666666667)
ENT.RagdollOnDeath = true
ENT.SpotDuration = 5

-- Stats --
ENT.SpawnHealth = 90000
ENT.ShoveResistance = true
ENT.DamageMultipliers = {}

-- AI --
ENT.MeleeAttackRange = 50
ENT.RangeAttackRange = 650
ENT.ReachEnemyRange = 50
ENT.AvoidEnemyRange = 0

-- Relationships --
ENT.Factions = {"FACTION_SLENDER"}
ENT.Frightening = true

-- Movements/animations --
ENT.UseWalkframes = false
ENT.WalkAnimation = "cwoody_walk2"
ENT.RunAnimation = "Run_All_Panicked"
ENT.IdleAnimation = "cwoody_idle2"
ENT.JumpAnimation = "sprint_all"
ENT.RunSpeed = 350
ENT.WalkSpeed = 60

-- Climbing --
ENT.ClimbLedges = false
ENT.ClimbProps = false
ENT.ClimbLadders = false

-- Detection --
ENT.EyeBone = "head"
ENT.EyeOffset = Vector(10, 0, 1)
ENT.EyeAngle = Angle(0, 0, 0)

-- Possession --
ENT.PossessionEnabled = true
ENT.PossessionMovement = POSSESSION_MOVE_1DIR
ENT.PossessionViews = {
	{
		offset = Vector(0, 15, 15),
		distance = 70
	},
	{
		offset = Vector(7.5, 0, 0),
		distance = 0,
		eyepos = true
	}
}
ENT.PossessionBinds = {
	[IN_ATTACK] = {{
		coroutine = true,
		onkeydown = function(self)
			self:Timer(0.3, function()
			self:AttackFunction(666,self.DamageType)
			end)
			self:PlaySequenceAndMove("swing",1,self.PossessionFaceForward)
		end
	}},
	[IN_JUMP] = {{coroutine = true,onkeydown = function(self)self:Jump()end}}
}

if SERVER then
function ENT:AttackFunction(dmg,dmgtype,sndhit)
	if self.Flinching == true then return end
	self:Attack({
		damage = dmg,
		viewpunch = Angle(40, 0, 0),
		type = dmgtype,
		range=self.MeleeAttackRange-math.random(10),
		angle=135,
	}, function(self, hit)
		if self:GetSequenceName(self:GetSequence())=="att4" then return end
		if #hit == 0 then self:EmitSound("")return end 
		self:EmitSound("")
	end)
end

function ENT:CustomInitialize()
	self.Flinching = false
	self:SetDefaultRelationship(D_HT, 1)
	self:SetAttack("att1_l", true)
	self:SetCooldown("Range",math.random(3,3))
	self:SetCooldown("Flinch",math.random(3.2,6))
	self:SetModelScale(1.2)
	self:LightOn()
	self.Cr = ents.Create("obj_re7_bonemerge")
	self.Cr:SetModel("models/player/zombie_fast.mdl")
	self.Cr:Spawn()
	self.Cr:SetParent(self)
	self.Cr:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	self.Cr1 = ents.Create("obj_re7_bonemerge")
	self.Cr1:SetModel("models/player/items/humans/top_hat.mdl")
	self.Cr1:Spawn()
	self.Cr1:SetParent(self)
	self.Cr1:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	self:SetMaterial("Invisible")
	local d = math.random(1,2)
	if d==1 then
	self.IdleAnimation = "cwoody_idle2"
	elseif d==2 then
	self.IdleAnimation = "cwoody_idle4"
	end
end
function ENT:OnIdle()
	local d = math.random(1,2)
	if d==1 then
	self.IdleAnimation = "cwoody_idle2"
	elseif d==2 then
	self.IdleAnimation = "cwoody_idle4"
	end
	self:AddPatrolPos(self:RandomPos(1500))
end
function ENT:HandleAnimEvent(a,b,c,d,e)
	if e == "step" then 
		self:EmitSound("slender/trypo/bigsteppy"..math.random(4)..".mp3")
	end
end

function ENT:OnLandOnGround()
	if self:IsDead() then return end
	self:CallInCoroutineOverride(function(self, delay)
		self:PlaySequence("jumpland_MELEE_ALLCLASS")
	end)
end

function ENT:OnSpawn()
	self:EmitSound("npc/manhack/grind_flesh1.wav")
	ParticleEffect("tfc_sniper_mist",self:GetPos()+Vector(0,0,0),Angle(0,0,0),nil)
end

function ENT:LightOn()
	self.Light1 = self:SF_DynamicLight(Color(255,0,0),130,7,0,2)
	self.Light1:SetPos(self:GetPos() +self:GetForward()*110 +self:GetUp()*60 +self:GetRight())
	self.Light1:SetParent(self)
	self.Light1:SetOwner(self)
end
function ENT:SF_DynamicLight(color, radius, brightness,style,att)
	if color == nil then color = Color(255, 255, 255) end
	if not isnumber(radius) then radius = 1000 end
	radius = math.Clamp(radius, 0, math.huge)
	if not isnumber(brightness) then brightness = 1 end
	brightness = math.Clamp(brightness, 0, math.huge)
	local light = ents.Create("light_dynamic")
	light:SetKeyValue("brightness", tostring(brightness))
	light:SetKeyValue("distance", tostring(radius))
	light:SetKeyValue("style", tostring(style))
	-- light:SetKeyValue("spawnflags",1)
	light:Fire("Color", tostring(color.r).." "..tostring(color.g).." "..tostring(color.b))
	light:SetParent(self)
	light:SetLocalPos(Vector(vec,0,50))
	light:Spawn()
	light:Activate()
	light:Fire("TurnOn", "", 0)
	light:Fire("setparentattachment","")
	self:DeleteOnRemove(light)
	return light
end
function ENT:OnMeleeAttack(enemy)
	self:Timer(0.3, function()
	self:AttackFunction(666,self.DamageType)
	end)
	self:PlaySequenceAndMove("swing",1,self.FaceEnemy)
end
-- Damage --
function ENT:OnTakeDamage(dmg)
	if self:GetCooldown("Flinch") == 0 and self.Flinching == false then
	self:CallInCoroutineOverride(function(self, delay)
	self.Flinching = true
	self:PlaySequenceAndWait("cower",0.8)
	self:PlaySequenceAndWait("cower_idle",1)
	self.Flinching = false
	end)
	self:SetCooldown("Flinch",math.random(3.2,6))
	end
end
function ENT:OnPhysDamage(ent, data)
	if string.find(data.HitEntity:GetClass(), "tf_") then return end
	return (data.TheirOldVelocity:Length()*data.HitObject:GetMass())/1000
end
function ENT:_HandleCollide(data)
	if string.find(data.HitEntity:GetClass(), "tf_") then return end
	local ent = data.HitEntity
	if not IsValid(ent) then return end
	local class = ent:GetClass()
	local phys = data.HitObject
	if class == "prop_combine_ball" then
	if self:IsFlagSet(FL_DISSOLVING) then return end
	if not self:OnCombineBall(ent) then
	if not self:IsDead() then
		local dmg = DamageInfo()
		local owner = ent:GetOwner()
		dmg:SetAttacker(IsValid(owner) and owner or ent)
		dmg:SetInflictor(ent)
		dmg:SetDamage(1000)
		dmg:SetDamageType(DMG_DISSOLVE)
		dmg:SetDamageForce(ent:GetVelocity())
		self:TakeDamageInfo(dmg)
	else self:DrG_Dissolve() end
	ent:EmitSound("NPC_CombineBall.KillImpact")
	end
	elseif not ent:IsPlayerHolding() then
	local damage = math.floor(self:OnPhysDamage(ent, data))
	if damage > math.max(0, self.MinPhysDamage) then
		local dmg = DamageInfo()
		if ent:IsVehicle() and IsValid(ent:GetDriver()) then
		dmg:SetAttacker(ent:GetDriver())
		elseif IsValid(ent:GetPhysicsAttacker()) then
		dmg:SetAttacker(ent:GetPhysicsAttacker())
		else dmg:SetAttacker(ent) end
		dmg:SetInflictor(ent)
		dmg:SetDamage(damage)
		if ent:IsVehicle() then
		dmg:SetDamageType(DMG_VEHICLE)
		else dmg:SetDamageType(DMG_CRUSH) end
		dmg:SetDamageForce(phys:GetVelocity())
		self:TakeDamageInfo(dmg)
		end
	end
end
function ENT:OnNewEnemy(enemy)
end
function ENT:OnOtherKilled(ent, dmg)
	local attacker = dmg:GetAttacker()
	if IsValid(attacker) and attacker == self then
		if ent:IsPlayer() then
		PrintMessage(HUD_PRINTTALK, "YOU DIDN'T OUT RUN SIMPLY!!!!11111!!!")
		end
	end
end

function ENT:OnFatalDamage()return false end
function ENT:OnDeath(dmg)
	self:StopSound("slender/duckmedic/chase_music.wav")
end
function ENT:OnRagdoll()
end
function ENT:OnLost()
end
function ENT:OnRemove()
	self:EmitSound("npc/manhack/grind_flesh1.wav")
	ParticleEffect("tfc_sniper_mist",self:GetPos()+Vector(0,0,0),Angle(0,0,0),nil)
end

function ENT:CustomThink()
	self:RemoveAllDecals()
end
function ENT:OnUpdateAnimation()
	if self:IsDead() then return end
	if !self:IsOnGround() then return self.JumpAnimation, 1
	elseif self:IsRunning() then return self.RunAnimation, self.RunAnimRate
	elseif self:IsMoving() then return self.WalkAnimation, self.WalkAnimRate
	else return self.IdleAnimation, self.IdleAnimRate end
end

function ENT:CallInCoroutineOverride(callback)
	local oldThread = self.BehaveThread
	self.BehaveThread = coroutine.create(function()
		callback(self)
		self.BehaveThread = oldThread
	end)
end
end

-- DO NOT TOUCH --
AddCSLuaFile()
DrGBase.AddNextbot(ENT)