if not DrGBase then return end -- return if DrGBase isn't installed
ENT.Base = "drgbase_nextbot" -- DO NOT TOUCH (obviously)

-- Misc --
ENT.PrintName = "Bobby (White)"
ENT.Category = "We Happy Few"
ENT.Models = {"models/scot_sf/bobby/bobby.mdl"}
ENT.BloodColor = BLOOD_COLOR_RED
ENT.CollisionBounds = Vector(14, 14, 83)
ENT.RagdollOnDeath = true
ENT.OnIdleSounds={""}
ENT.IdleSoundDelay = 4
ENT.SpotDuration = 5

-- Stats --
ENT.SpawnHealth = 1250
ENT.ShoveResistance = true
ENT.DamageMultipliers = {}

-- AI --
ENT.MeleeAttackRange = 50
ENT.ReachEnemyRange = 50
ENT.AvoidEnemyRange = 0

-- Relationships --
ENT.Factions = {"FACTION_SLENDER"}
ENT.Frightening = true

-- Movements/animations --
ENT.UseWalkframes = false
ENT.WalkAnimation = "Bobby_Walk_Unarmed"
ENT.RunAnimation = "Bobby_Charge_RM"
ENT.IdleAnimation = "Bobby_idle_nowep"
ENT.JumpAnimation = "Bobby_Charge_RM"
ENT.RunSpeed = 400
ENT.WalkSpeed = 65

-- Climbing --
ENT.ClimbLedges = false
ENT.ClimbProps = false
ENT.ClimbLadders = false

-- Detection --
ENT.EyeBone = "head"
ENT.EyeOffset = Vector(10, 0, 1)
ENT.EyeAngle = Angle(0, 0, 0)

-- Possession --
ENT.PossessionEnabled = true
ENT.PossessionMovement = POSSESSION_MOVE_1DIR
ENT.PossessionViews = {
	{
		offset = Vector(0, 15, 15),
		distance = 70
	},
	{
		offset = Vector(7.5, 0, 0),
		distance = 0,
		eyepos = true
	}
}
ENT.PossessionBinds = {
	[IN_ATTACK] = {{
		coroutine = true,
		onkeydown = function(self)
			self:Timer(0.3, function()
			self:AttackFunction(50,self.DamageType)
			end)
			local a = math.random(1,2)
			if a==1 then
			self:PlaySequenceAndMove("Bobby_Attack1",1,self.PossessionFaceForward)
			elseif a==2 then
			self:PlaySequenceAndMove("Bobby_Attack2",1,self.PossessionFaceForward)
			end
		end
	}},
	[IN_JUMP] = {{coroutine = true,onkeydown = function(self)self:Jump()end}}
}

if SERVER then
function ENT:AttackFunction(dmg,dmgtype,sndhit)
	if self.Flinching == true or self:IsDead() then return end
	self:Attack({
		damage = dmg,
		viewpunch = Angle(40, 0, 0),
		type = dmgtype,
		range=self.MeleeAttackRange-math.random(10),
		angle=135,
	}, function(self, hit)
		if self:GetSequenceName(self:GetSequence())=="att4" then return end
		if #hit == 0 then self:EmitSound("weapons/cbar_miss1.wav")return end 
		self:EmitSound("weapons/bat_hit.wav")
	end)
end

function ENT:CustomInitialize()
	self:SequenceEvent("Bobby_Walk_NoWep",{5/9,22/3},self.Step)
	self:SequenceEvent("Bobby_Walk_RM",{5/9,22/3},self.Step)
	self:SequenceEvent("Bobby_Charge_RM",{5/9,22/3},self.Step)
	self:SetDefaultRelationship(D_HT, 1)
	self:SetAttack("att1_l", true)
	self:SetCooldown("Twitch",math.random(3,3))
	self:SetBodygroup(1,1)
	self:SetSkin(2)
	self.LanHelp = ents.Create("obj_re7_bonemerge")
	self.LanHelp:SetModel("models/yolojoe/compulsiongames/wehappyfew/bobby2.mdl")
	self.LanHelp:Spawn()
	self.LanHelp:SetMaterial("Invisible")
	self.LanHelp:DrawShadow(false)
	self.LanHelp:SetParent(self)
	self.LanHelp:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL))
	local d = math.random(1,6)
	if d==1 then
	self.IdleAnimation = "Bobby_idle_NoWep"
	self.WalkAnimation = "Bobby_Walk_NoWep"
	elseif d==2 then
	self.IdleAnimation = "Bobby_Gloveidle"
	elseif d==3 then
	self.IdleAnimation = "Bobby_Angryidle"
	elseif d==4 then
	self.IdleAnimation = "Bobby_Angryidle2"
	elseif d==5 then
	self.IdleAnimation = "Bobby_Chillidle"
	elseif d==6 then
	self.IdleAnimation = "Bobby_idle_Unarmed"
	self.WalkAnimation = "Bobby_Walk_Unarmed"
	end
end
function ENT:Step()
	self:EmitSound("slender/wehappyfew/bobby_step"..math.random(2)..".wav")
end

function ENT:OnLandOnGround()
	if self:IsDead() then return end
	self:CallInCoroutineOverride(function(self, delay)
		self:PlaySequence("jumpland_MELEE_ALLCLASS")
	end)
end

function ENT:OnSpawn()
end

function ENT:OnMeleeAttack(enemy)
	self:Timer(0.3, function()
	self:AttackFunction(50,self.DamageType)
	end)
	local a = math.random(1,2)
	if a==1 then
	self:PlaySequenceAndMove("Bobby_Attack1",1,self.FaceEnemy)
	elseif a==2 then
	self:PlaySequenceAndMove("Bobby_Attack2",1,self.FaceEnemy)
	end
end
-- Damage --
function ENT:OnTraceAttack(dmg,dir,tr)
end
function ENT:OnPhysDamage(ent, data)
	if string.find(data.HitEntity:GetClass(), "tf_") then return end
	return (data.TheirOldVelocity:Length()*data.HitObject:GetMass())/1000
end
function ENT:_HandleCollide(data)
	if string.find(data.HitEntity:GetClass(), "tf_") then return end
	local ent = data.HitEntity
	if not IsValid(ent) then return end
	local class = ent:GetClass()
	local phys = data.HitObject
	if class == "prop_combine_ball" then
	if self:IsFlagSet(FL_DISSOLVING) then return end
	if not self:OnCombineBall(ent) then
	if not self:IsDead() then
		local dmg = DamageInfo()
		local owner = ent:GetOwner()
		dmg:SetAttacker(IsValid(owner) and owner or ent)
		dmg:SetInflictor(ent)
		dmg:SetDamage(1000)
		dmg:SetDamageType(DMG_DISSOLVE)
		dmg:SetDamageForce(ent:GetVelocity())
		self:TakeDamageInfo(dmg)
	else self:DrG_Dissolve() end
	ent:EmitSound("NPC_CombineBall.KillImpact")
	end
	elseif not ent:IsPlayerHolding() then
	local damage = math.floor(self:OnPhysDamage(ent, data))
	if damage > math.max(0, self.MinPhysDamage) then
		local dmg = DamageInfo()
		if ent:IsVehicle() and IsValid(ent:GetDriver()) then
		dmg:SetAttacker(ent:GetDriver())
		elseif IsValid(ent:GetPhysicsAttacker()) then
		dmg:SetAttacker(ent:GetPhysicsAttacker())
		else dmg:SetAttacker(ent) end
		dmg:SetInflictor(ent)
		dmg:SetDamage(damage)
		if ent:IsVehicle() then
		dmg:SetDamageType(DMG_VEHICLE)
		else dmg:SetDamageType(DMG_CRUSH) end
		dmg:SetDamageForce(phys:GetVelocity())
		self:TakeDamageInfo(dmg)
		end
	end
end
function ENT:OnNewEnemy(enemy)
	self.OnIdleSounds={"slender/wehappyfew/bobby_chase1.mp3","slender/wehappyfew/bobby_chase2.mp3","slender/wehappyfew/bobby_chase3.mp3","slender/wehappyfew/bobby_chase4.mp3","slender/wehappyfew/bobby_chase5.mp3","slender/wehappyfew/bobby_chase6.mp3","slender/wehappyfew/bobby_chase7.mp3"}
	self.IdleSoundDelay = 4
	self.Lantern = ents.Create("obj_re7_bonemerge")
	self.Lantern:SetModel("models/we happy few/weapons/leadpipe/leadpipe.mdl")
	self.Lantern:SetPos(self.LanHelp:GetPos() +self.LanHelp:GetForward()*12 +self.LanHelp:GetRight()*-0.5 +self.LanHelp:GetUp()*-0.5 )
	self.Lantern:SetAngles(self.LanHelp:GetAngles()+Angle(93,0,0))
	self.Lantern:Spawn()
	self.Lantern:SetModelScale(1.03)
	self.Lantern:SetOwner(self.LanHelp)
	self.Lantern:SetParent(self.LanHelp, 70)
	self.Lantern:AddEffects(bit.bor(EF_FOLLOWBONE))
	self.Lantern2 = ents.Create("obj_re7_bonemerge")
	self.Lantern2:SetModel("models/we happy few/items/gasmask/gasmask.mdl")
	self.Lantern2:SetPos(self.LanHelp:GetPos() +self.LanHelp:GetForward()*3.5 +self.LanHelp:GetRight()*-3.2 +self.LanHelp:GetUp()*-0.2 )
	self.Lantern2:SetAngles(self.LanHelp:GetAngles()+Angle(0,90,90))
	self.Lantern2:Spawn()
	self.Lantern2:SetModelScale(1.18)
	self.Lantern2:SetOwner(self.LanHelp)
	self.Lantern2:SetParent(self.LanHelp, 17)
	self.Lantern2:AddEffects(bit.bor(EF_FOLLOWBONE))
	local d = math.random(1,2)
	if d==1 then
	self.IdleAnimation = "Bobby_idle"
	elseif d==2 then
	self.IdleAnimation = "Bobby_idle2"
	end
	for k,v in pairs(ents.FindByClass("drg_scot_whf_bobby")) do
	if self:GetPos():Distance(v:GetPos()) < 450 and v:IsAlive() and self:IsAlive() then
	v:AddEntityRelationship( enemy, D_HT, 99 )
	v:FaceInstant(enemy)
	else
	end
	end
	for k,v in pairs(ents.FindByClass("drg_scot_whf_bobbyred")) do
	if self:GetPos():Distance(v:GetPos()) < 450 and v:IsAlive() and self:IsAlive() then
	v:AddEntityRelationship( enemy, D_HT, 99 )
	v:FaceInstant(enemy)
	else
	end
	end
	for k,v in pairs(ents.FindByClass("drg_scot_whf_bobbyg")) do
	if self:GetPos():Distance(v:GetPos()) < 450 and v:IsAlive() and self:IsAlive() then
	v:AddEntityRelationship( enemy, D_HT, 99 )
	v:FaceInstant(enemy)
	else
	end
	end
	for k,v in pairs(ents.FindByClass("drg_scot_whf_bobbyredg")) do
	if self:GetPos():Distance(v:GetPos()) < 450 and v:IsAlive() and self:IsAlive() then
	v:AddEntityRelationship( enemy, D_HT, 99 )
	v:FaceInstant(enemy)
	else
	end
	end
	for k,v in pairs(ents.FindByClass("drg_scot_whf_bobbywhite")) do
	if self:GetPos():Distance(v:GetPos()) < 450 and v:IsAlive() and self:IsAlive() then
	v:AddEntityRelationship( enemy, D_HT, 99 )
	v:FaceInstant(enemy)
	else
	end
	end
end
function ENT:OnOtherKilled(ent, dmg)
end
function ENT:OnOtherKilled(ent, dmg)
	local attacker = dmg:GetAttacker()
	if IsValid(attacker) and attacker == self then
		local p = math.random(1,4)
		if p==1 then
		self:EmitSound("slender/wehappyfew/bobby_kill1.mp3")
		elseif p==2 then
		self:EmitSound("slender/wehappyfew/bobby_kill2.mp3")
		elseif p==3 then
		self:EmitSound("slender/wehappyfew/bobby_kill3.mp3")
		elseif p==4 then
		self:EmitSound("slender/wehappyfew/bobby_kill4.mp3")
		end
		self.OnIdleSounds={"slender/wehappyfew/bobby_search1.mp3","slender/wehappyfew/bobby_search2.mp3","slender/wehappyfew/bobby_search3.mp3","slender/wehappyfew/bobby_search4.mp3","slender/wehappyfew/bobby_search5.mp3"}
		self.IdleSoundDelay = 4
	end
end

function ENT:OnFatalDamage()return false end
function ENT:OnDeath(dmg)
	self:SetCollisionBounds( Vector (-11, -11, 0), Vector (11, 11, 5) )
	self:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
	self.OnIdleSounds={""}
	self:StopSound("slender/duckmedic/chase_music.wav")
	SafeRemoveEntityDelayed(self,80)
	self:PlaySequenceAndMove("bobby_death")
	self:PauseCoroutine(false)
end
function ENT:OnRagdoll()
end
function ENT:OnLost()
	self.OnIdleSounds={"slender/wehappyfew/bobby_search1.mp3","slender/wehappyfew/bobby_search2.mp3","slender/wehappyfew/bobby_search3.mp3","slender/wehappyfew/bobby_search4.mp3","slender/wehappyfew/bobby_search5.mp3"}
	self.IdleSoundDelay = 4
end
function ENT:OnRemove()
end

function ENT:CustomThink()
	self:RemoveAllDecals()
	if self:IsDead() then
	self.OnIdleSounds={""}
	end
end
function ENT:OnUpdateAnimation()
	if self:IsDead() then return end
	if !self:IsOnGround() then return self.JumpAnimation, 1
	elseif self:IsRunning() then return self.RunAnimation, self.RunAnimRate
	elseif self:IsMoving() then return self.WalkAnimation, self.WalkAnimRate
	else return self.IdleAnimation, self.IdleAnimRate end
end

function ENT:CallInCoroutineOverride(callback)
	local oldThread = self.BehaveThread
	self.BehaveThread = coroutine.create(function()
		callback(self)
		self.BehaveThread = oldThread
	end)
end
end

-- DO NOT TOUCH --
AddCSLuaFile()
DrGBase.AddNextbot(ENT)